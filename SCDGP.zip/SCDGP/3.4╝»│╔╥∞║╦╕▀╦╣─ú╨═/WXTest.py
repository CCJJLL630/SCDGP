import itchat
from apscheduler.schedulers.blocking import BlockingScheduler


def job_function():
    # 发送"午安"给文件助手
    itchat.send("午安", toUserName="无锡倒霉蛋关爱中心")


sched = BlockingScheduler()

# 任务会在每天中午12：00触发
sched.add_job(job_function, 'cron', hour=21)

if __name__ == '__main__':
    itchat.login()
    sched.start()
    itchat.run()
