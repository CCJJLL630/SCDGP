import math

import numpy as np
import pandas as pd
import sklearn.feature_selection
import tensorflow as tf
import matplotlib.pyplot as plt
from scikeras.wrappers import KerasRegressor
from tensorflow import keras

np.random.seed(42)
import gpflow
import gpflux

from gpflow.config import default_float
from sklearn.metrics import median_absolute_error, explained_variance_score, mean_absolute_error, mean_squared_error, \
    r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
#import stackingModel

tf.keras.backend.set_floatx("float64")

# dataframe = pd.read_csv("data/jiedianchangshu.csv", header=None)
# dataframe = pd.read_csv("data/covid-Italy.csv", header=None)
# dataframe = pd.read_excel("data/25_soc2000.xls", header=0)
# dataframe = pd.read_csv("data/jiediansunhao.csv", header=None)
# dataframe = pd.read_csv("data/bancao.csv", header=None)
# dataframe = pd.read_csv("data/multi792.csv", header=None)
# dataframe = pd.read_csv("data/battery4900.csv", header=None)
# dataframe = pd.read_csv("data/battery12000.csv", header=None)
# dataframe = pd.read_csv("data/battery_origin.csv", header=None)
# dataframe = dataframe.sample(frac=0.1, replace=False, random_state=42)
# dataframe = pd.read_csv("data/pushi/CBM.csv", header=None)
# dataframe = pd.read_csv("data/pushi/concrete.csv", header=None)
# dataframe = pd.read_csv("data/pushi/kin8nm.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-red.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-white.csv", header=None)
# dataframe = pd.read_csv("data/pushi/yacht.csv", header=None)
#dataframe = pd.read_csv('E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\\motor_100W_pm.csv', header=None)
dataframe = pd.read_csv('E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\dianji_cjl.CSV',header=None)
dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:, 0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

X = df2[:, 0:column - 1]
Y = df2[:, column - 1:column]

from sklearn.preprocessing import scale, MinMaxScaler

# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)


num_data, input_dim = X.shape

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)
print(X_train.shape)
# X_train = X_train.reshape(X_train.shape[0],1,X_train.shape[1])
# X_test = X_test.reshape(X_test.shape[0],1,X_test.shape[1])
# print(X_train.shape)
num_data = len(X)
num_inducing = 20
output_dim = Y_train.shape[1]
print(output_dim)
# output_dim = 100

SE_kernel = gpflow.kernels.SquaredExponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_SE = gpflux.layers.GPLayer(
    SE_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
RQ_kernel = gpflow.kernels.RationalQuadratic()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_RQ = gpflux.layers.GPLayer(
    RQ_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
Matern52_kernel = gpflow.kernels.Matern52()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_Matern52 = gpflux.layers.GPLayer(
    Matern52_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
Matern32_kernel = gpflow.kernels.Matern32()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_Matern32 = gpflux.layers.GPLayer(
    Matern32_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
Exp_kernel = gpflow.kernels.Exponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_Exp = gpflux.layers.GPLayer(
    Exp_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
likelihood = gpflow.likelihoods.Gaussian(0.1)

# So that Keras can track the likelihood variance, we need to provide the likelihood as part of a "dummy" layer:
likelihood_container = gpflux.layers.TrackableLayer()
likelihood_container.likelihood = likelihood


class MLPRegressor(KerasRegressor):

    def __init__(
            self,
            # hidden_layer_sizes=(100, ),
            optimizer="adam",
            optimizer__learning_rate=0.001,
            epochs=10,
            verbose=0,
            alpha = 0,
            **kwargs,
    ):
        super().__init__(**kwargs)
        # self.hidden_layer_sizes = hidden_layer_sizes
        self.optimizer = optimizer
        self.epochs = epochs
        self.verbose = verbose
        self.alpha = alpha

    def _keras_build_fn(self,compile_kwargs):
        model = keras.Sequential()
        # inp = keras.layers.Input()
        # model.add(inp)

        random_num = self.alpha
        x = np.linspace(1, 10, 100)

        result = []
        for val in x:
            temp = np.exp(val) / np.sqrt(val + random_num)
            if temp < 0.5:
                result.append(temp ** 2)
            else:
                result.append(np.log(temp))
        output = np.array(result)
        inp = keras.layers.Input(shape=(self.n_features_in_))
        model.add(inp)
        model.add(keras.layers.Dense(50, activation="relu"))
        model.add(keras.layers.Dense(50, activation="relu"))
        model.add(keras.layers.Dense(50, activation="relu"))
       # model.add(keras.layers.Dense(50, activation="relu"))
        model.add(keras.layers.Dense(1, activation="linear"))
        model.add(gp_layer_Exp)
        model.add(gp_layer_Exp)
        model.add(gp_layer_Exp)

        model.add(likelihood_container)

        # out = keras.layers.Dense(1)
        # model.add(out)
        loss = gpflux.losses.LikelihoodLoss(likelihood)
        # model.compile(loss="mse", optimizer=compile_kwargs["optimizer"])
        model.compile(loss=loss, optimizer=compile_kwargs["optimizer"])
        return model


model_Exp_kernel = MLPRegressor()
#model_Exp_kernel =  model._keras_build_fn()