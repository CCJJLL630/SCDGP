from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import tensorflow as tf
pmean = []
pmean.append(0.0197)
ty = []
ty.append(0.0248)
mm = []
mm.append(0.0197)
R2 = r2_score(ty,pmean, multioutput='raw_values')  # 拟合优度
R22 = 1 - tf.sqrt(1 - R2)
# Mse = mean_squared_error(test_y, predictive_means.mean(0))  # 均方差
# Mae = mean_absolute_error(test_y, predictive_means.mean(0),
#                               sample_weight=None,
#                               multioutput='uniform_average')  # 平均绝对误差
# Variance = explained_variance_score(test_y, predictive_means.mean(0),
#                                         sample_weight=None,
#                                         multioutput='uniform_average')  # 可释方差得分
# Meae = median_absolute_error(test_y, predictive_means.mean(0))  # 中值绝对误差
# R2 = r2_score(y_test, y_pred, multioutput='raw_values')  # 拟合优度
# R22 = 1 - tf.sqrt(1 - R2)
# Mse = mean_squared_error(y_test, y_pred)  # 均方差
# Mae = mean_absolute_error(y_test, y_pred,
#                           sample_weight=None,
#                           multioutput='uniform_average')  # 平均绝对误差
# Variance = explained_variance_score(y_test, y_pred,
#                                     sample_weight=None,
#                                     multioutput='uniform_average')  # 可释方差得分
# Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差

print("R2_gpytorch_test : " , R2)
print("R22 : " , R22)