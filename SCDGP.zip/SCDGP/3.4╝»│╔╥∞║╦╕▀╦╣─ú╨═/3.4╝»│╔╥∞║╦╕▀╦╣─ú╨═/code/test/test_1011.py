import tensorflow as tf
import gpflow
import gpflux
import numpy as np
import matplotlib.pyplot as plt
from sklearn import manifold
from sklearn.decomposition import KernelPCA
from sklearn.model_selection import train_test_split
import pandas as pd
from tqdm import tqdm

import tensorflow_probability as tfp
from sklearn.neighbors import KernelDensity
dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\jiedianchangshu.csv',header=None)


dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

X = df2[:,0:1]
Y = df2[:,column-1:column]

#Y = Y.ravel()
# for battery_prediction
# x = df2[:,1:column-1]

# X = df2[:,0:6]
# X = np.delete(X, 3, 1)
# X = np.delete(X, 4, 1)
# print('x_shape',X.shape)
# Y = df2[:,6:7]
# Y = df2[:,7:8]
# Y = df2[:8:9]
# Y = df2[:,9:10]
# Y = df2[:,10:11]
from sklearn.preprocessing import scale, MinMaxScaler,RobustScaler,StandardScaler
# X = scale(X)
# Y = scale(Y)
scaler = StandardScaler()
X = scaler.fit_transform(X)
Y = scaler.fit_transform(Y)
# kPCA = KernelPCA(kernel="poly",n_components=8)
# se = manifold.LocallyLinearEmbedding(n_components=1,n_neighbors=50)
# X = kPCA.fit_transform(X)
# kPCA1 = KernelPCA(kernel="rbf",n_components=2)
# Y = kPCA1.fit_transform(Y)
X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.5, random_state=66)
Y_train = tf.cast(Y_train,dtype=tf.float32)
num_data, input_dim = X.shape
#num_data = len(X)
NUM_INDUCING = 20
print(X.shape)

kernel = gpflow.kernels.SquaredExponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), NUM_INDUCING).reshape(-1, 1)
)
gp_layer = gpflux.layers.GPLayer(
    kernel, inducing_variable, num_data=num_data, num_latent_gps=1
)
likelihood = gpflow.likelihoods.Gaussian(0.01)

# So that Keras can track the likelihood variance, we need to provide the likelihood as part of a "dummy" layer:
likelihood_container = gpflux.layers.TrackableLayer()
likelihood_container.likelihood = likelihood
likelihood_layer = gpflux.layers.LikelihoodLayer(gpflow.likelihoods.Gaussian(0.1))
single_layer_dgp = gpflux.models.DeepGP([gp_layer], likelihood_layer)
model = single_layer_dgp.as_training_model()
model.compile(tf.optimizers.Adam(0.01))
# loss = gpflux.losses.LikelihoodLoss(likelihood)
# model.compile(loss=loss, optimizer="adam")

history = model.fit({"inputs": X_train, "targets": Y_train}, epochs=int(1e3), verbose=0)
#history = model.fit(X_train,Y_train)
y_pred = model.predict(X_test)
print(y_pred)
# fig, ax = plt.subplots()
# ax.plot(history.history["loss"])
# ax.set_xlabel('Epoch')
# ax.set_ylabel('Loss')