#!/usr/bin/env python3

import math
from typing import Optional

import torch

from gpytorch.functions import MaternCovariance, RBFCovariance
from gpytorch.kernels import MaternKernel
from gpytorch.kernels.rbf_kernel import postprocess_rbf
from gpytorch.settings import trace_mode
from gpytorch.kernels.kernel import Kernel


class MexhatKernel(Kernel):

    # has_lengthscale = True
    #
    # def __init__(self, nu: Optional[float] = 2.5, **kwargs):
    #     if nu not in {0.5, 1.5, 2.5}:
    #         raise RuntimeError("nu expected to be 0.5, 1.5, or 2.5")
    #     super(MexhatKernel, self).__init__(**kwargs)
    #     self.nu = nu
    #
    # def forward(self, x1, x2, diag=False, **params):
    #     if (
    #         x1.requires_grad
    #         or x2.requires_grad
    #         or (self.ard_num_dims is not None and self.ard_num_dims > 1)
    #         or diag
    #         or params.get("last_dim_is_batch", False)
    #         or trace_mode.on()
    #     ):
    #         mean = x1.reshape(-1, x1.size(-1)).mean(0)[(None,) * (x1.dim() - 1)]
    #
    #         x1_ = (x1 - mean).div(self.lengthscale)
    #         x2_ = (x2 - mean).div(self.lengthscale)
    #         distance = self.covar_dist(x1_, x2_, diag=diag, **params)
    #         exp_component = torch.exp(-math.sqrt(self.nu * 2) * distance)
    #
    #         if self.nu == 0.5:
    #             constant_component = 1
    #         elif self.nu == 1.5:
    #             constant_component = (math.sqrt(3) * distance).add(1)
    #         elif self.nu == 2.5:
    #             constant_component = (math.sqrt(5) * distance).add(1).add(5.0 / 3.0 * distance ** 2)
    #         return constant_component * exp_component
    #     return MaternCovariance.apply(
    #         x1, x2, self.lengthscale, self.nu, lambda x1, x2: self.covar_dist(x1, x2, **params)
    #     )
    has_lengthscale = True

    def forward(self, x1, x2, diag=False, **params):
        if (
                x1.requires_grad
                or x2.requires_grad
                or (self.ard_num_dims is not None and self.ard_num_dims > 1)
                or diag
                or params.get("last_dim_is_batch", False)
                or trace_mode.on()
        ):
            x1_ = x1.div(self.lengthscale)
            x2_ = x2.div(self.lengthscale)
            return self.covar_dist(
                x1_, x2_, square_dist=True, diag=diag, dist_postprocess_func=postprocess_rbf, postprocess=True, **params
            )
        return RBFCovariance.apply(
            x1,
            x2,
            self.lengthscale,
            lambda x1, x2: self.covar_dist(
                x1, x2, square_dist=True, diag=False, dist_postprocess_func=postprocess_rbf, postprocess=False, **params
            ),
        )

