import math

from sklearn.datasets import make_friedman2
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, explained_variance_score, \
    median_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Sum, WhiteKernel
import matplotlib.pyplot as plt

X, y = make_friedman2(n_samples=1000, noise=0.1, random_state=10)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=36)

model_kernel = Sum(RBF([100, 1500, 1, 10], length_scale_bounds='fixed'), WhiteKernel(0.1, noise_level_bounds='fixed'))

model_gpr = GaussianProcessRegressor(kernel=model_kernel)

model_gpr.fit(X_train, y_train)

print(model_gpr.score(X_test, y_test))

y_pred, y_std = model_gpr.predict(X_test, return_std=True)

# plot_x = [i for i in range(X_test.shape[0])]
# plt.figure(dpi=300)
# plt.scatter(plot_x, y_test, color='red', label='test data')
# plt.plot(plot_x, y_mean, color='blue', label='y predict')
# plt.legend()
# plt.show()

# calculate metrics
R2 = r2_score(y_test, y_pred, multioutput='raw_values')  # 拟合优度
R22 = 1 - math.sqrt(1 - R2)
Mse = mean_squared_error(y_test, y_pred)  # 均方差
Mae = mean_absolute_error(y_test, y_pred,
                          sample_weight=None,
                          multioutput='uniform_average')  # 平均绝对误差
Variance = explained_variance_score(y_test, y_pred,
                                    sample_weight=None,
                                    multioutput='uniform_average')  # 可释方差得分
Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差
# if (R2 > 0.9100):
#     print('OK!',R2)
#     np.savetxt('y/y.csv',y_test,delimiter=',')
#     np.savetxt('y/y_pred.csv',y_pred,delimiter=',')

print("R2 :%.4f" % R2)
print("R22 :%.4f" % R22)
print("Mse :%.4f" % Mse)
print("Rmse :%.4f" % math.sqrt(Mse))
print("Mae :%.4f" % Mae)
print("Variance :%.4f" % Variance)
print("Meae :%.4f" % Meae)
