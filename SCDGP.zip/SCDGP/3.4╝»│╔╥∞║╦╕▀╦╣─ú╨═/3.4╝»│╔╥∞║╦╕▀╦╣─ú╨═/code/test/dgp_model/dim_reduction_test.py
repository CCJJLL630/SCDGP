import time

import torch
import tqdm
import gpytorch
from gpytorch.means import ConstantMean, LinearMean
from gpytorch.kernels import RBFKernel, ScaleKernel, MaternKernel, PolynomialKernel, RQKernel, SpectralMixtureKernel, \
    ProductStructureKernel, GridInterpolationKernel
from gpytorch.variational import VariationalStrategy, CholeskyVariationalDistribution, NaturalVariationalDistribution, \
    DeltaVariationalDistribution, MeanFieldVariationalDistribution, BatchDecoupledVariationalStrategy, \
    CiqVariationalStrategy, NNVariationalStrategy
from gpytorch.distributions import MultivariateNormal
from gpytorch.models import ApproximateGP, GP
from gpytorch.mlls import VariationalELBO, AddedLossTerm
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.models.deep_gps import DeepGPLayer, DeepGP
from gpytorch.mlls import DeepApproximateMLL

import urllib.request
import os
from scipy.io import loadmat
from math import floor
import pandas as pd
import numpy as np
import tensorflow as tf

# this is for running the notebook in our testing framework
from sklearn.metrics import median_absolute_error, explained_variance_score, mean_squared_error, mean_absolute_error, \
    r2_score

smoke_test = ('CI' in os.environ)

# important file


# if not smoke_test and not os.path.isfile('../elevators.mat'):
#     print('Downloading \'elevators\' UCI dataset...')
#     urllib.request.urlretrieve('https://drive.google.com/uc?export=download&id=1jhWL3YUHvXIaftia4qeAyDwVxo6j1alk', '../elevators.mat')
#
#
# if smoke_test:  # this is for running the notebook in our testing framework
#     X, y = torch.randn(1000, 3), torch.randn(1000)
# else:
#     data = torch.Tensor(loadmat('D:\CjlNoFile\组会文件\深度高斯过程\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\elevators.mat')['data'])
#     X = data[:, :-1]
#     X = X - X.min(0)[0]
#     X = 2 * (X / X.max(0)[0]) - 1
#     y = data[:, -1]
#
#
# train_n = int(floor(0.8 * len(X)))
# train_x = X[:train_n, :].contiguous()
# train_y = y[:train_n].contiguous()
# print(train_x.dtype)
# print('train_x.shape :',train_x.shape)
# print('train_y.shape :',train_y.shape)
# test_x = X[train_n:, :].contiguous()
# test_y = y[train_n:].contiguous()


# dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\jiediansunhao-cjl.CSV',header=None)
dataframe = pd.read_csv(
    'E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\motor20.csv', header=None)
# Time to train: 2468.80s

dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:, 0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)
df2 = df2.values

X = df2[:, 0:column - 1]
Y = df2[:, column - 1:column]
from sklearn.preprocessing import scale, MinMaxScaler, StandardScaler

# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)
# ss = StandardScaler()
# X = ss.fit_transform(X)
# Y = ss.fit_transform(Y)
X = X.astype(np.float32)
Y = Y.astype(np.float32)

X = torch.tensor(X)
Y = torch.tensor(Y)

# train_n = int(floor(0.8 * len(X)))
# train_x = X[:train_n, :].contiguous()
# train_y = Y[:train_n].contiguous()
# #train_y = torch.squeeze(train_y,1)
# print(type(train_x))
# print('train_x.shape :',train_x.shape)
# print('train_y.shape :',train_y.shape)
# test_x = X[train_n:, :].contiguous()
# test_y = Y[train_n:].contiguous()
# test_y = torch.squeeze(test_y,1)

train_n = int(floor(0.8 * len(X)))
train_x = X[:train_n, :].contiguous()
train_y = Y[:train_n].contiguous()
train_y = torch.squeeze(train_y, 1)
print(type(train_x))
print('train_x.shape :', train_x.shape)
print('train_x.shape[-1] :', train_x.shape[-1])
print('train_y.shape :', train_y.shape)
test_x = X[train_n:, :].contiguous()
test_y = Y[train_n:].contiguous()
test_y = torch.squeeze(test_y, 1)

if torch.cuda.is_available():
    train_x, train_y, test_x, test_y = train_x.cuda(), train_y.cuda(), test_x.cuda(), test_y.cuda()
from torch.utils.data import TensorDataset, DataLoader

train_dataset = TensorDataset(train_x, train_y)
train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
test_dataset = TensorDataset(test_x, test_y)
test_loader = DataLoader(test_dataset, batch_size=256,shuffle=False)
inducing_points = train_x[torch.randperm(train_x.size(0))[:2000]]

class GPModel(gpytorch.models.ApproximateGP):
    def __init__(self, inducing_points):
        variational_distribution = gpytorch.variational.NaturalVariationalDistribution(inducing_points.size(0))
        variational_strategy = gpytorch.variational.CiqVariationalStrategy(
            self, inducing_points, variational_distribution, learn_inducing_locations=True
        )
        super(GPModel, self).__init__(variational_strategy)
        self.mean_module = gpytorch.means.ConstantMean()
        self.covar_module = gpytorch.kernels.ScaleKernel(
            gpytorch.kernels.MaternKernel(nu=2.5, ard_num_dims=11)
        )
        self.covar_module.base_kernel.initialize(lengthscale=0.01)  # Specific to the 3droad dataset

    def forward(self, x):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)


model = GPModel(inducing_points=inducing_points)
likelihood = gpytorch.likelihoods.GaussianLikelihood()

if torch.cuda.is_available():
    model = model.cuda()
    likelihood = likelihood.cuda()

variational_ngd_optimizer = gpytorch.optim.NGD(model.variational_parameters(), num_data=train_y.size(0), lr=0.01)

hyperparameter_optimizer = torch.optim.Adam([
    {'params': model.hyperparameters()},
    {'params': likelihood.parameters()},
], lr=0.01)

model.train()
likelihood.train()
mll = gpytorch.mlls.VariationalELBO(likelihood, model, num_data=train_y.size(0))

num_epochs = 1 if smoke_test else 4
epochs_iter = tqdm.tqdm(range(num_epochs), desc="Epoch")
for i in epochs_iter:
    minibatch_iter = tqdm.tqdm(train_loader, desc="Minibatch", leave=False)

    for x_batch, y_batch in minibatch_iter:
        variational_ngd_optimizer.zero_grad()
        hyperparameter_optimizer.zero_grad()
        output = model(x_batch)
        loss = -mll(output, y_batch)
        minibatch_iter.set_postfix(loss=loss.item())
        loss.backward()
        variational_ngd_optimizer.step()
        hyperparameter_optimizer.step()

model.eval()
likelihood.eval()
means = torch.tensor([0.])
with torch.no_grad():
    for x_batch, y_batch in test_loader:
        preds = model(x_batch)
        means = torch.cat([means, preds.mean.cpu()])
means = means[1:]
print('Test MAE: {}'.format(torch.mean(torch.abs(means - test_y.cpu()))))