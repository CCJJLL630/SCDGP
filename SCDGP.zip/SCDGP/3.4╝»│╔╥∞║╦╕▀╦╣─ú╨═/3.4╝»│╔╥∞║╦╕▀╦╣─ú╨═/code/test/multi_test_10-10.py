import gpflow
import numpy as np

#from gpflow.ci_utils import reduce_in_tests
import pandas as pd
from sklearn import manifold
from sklearn.decomposition import KernelPCA
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, explained_variance_score, \
    median_absolute_error
from sklearn.model_selection import train_test_split

X1 = np.random.rand(100, 1)  # Observed locations for first output
X2 = np.random.rand(50, 1) * 0.5  # Observed locations for second output
#print(X2)
Y1 = np.sin(6 * X1) + np.random.randn(*X1.shape) * 0.03
Y2 = np.sin(6 * X2 + 0.7) + np.random.randn(*X2.shape) * 0.1

#print(Y2.shape)




dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\jiediansunhao-cjl.CSV',header=None)
dataset = dataframe.values
row, column = dataset.shape
#print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

# X = df2[:,0:column-1]
# Y = df2[:,column-1:column]
X = df2[:,0:column-2]
Y = df2[:,column-2:column]
# for battery_prediction
# x = df2[:,1:column-1]

# X = df2[:,0:6]
# X = np.delete(X, 3, 1)
# X = np.delete(X, 4, 1)
# print('x_shape',X.shape)
# Y = df2[:,6:7]
# Y = df2[:,7:8]
# Y = df2[:8:9]
# Y = df2[:,9:10]
# Y = df2[:,10:11]
from sklearn.preprocessing import scale, MinMaxScaler
# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)

# from sklearn.decomposition import PCA
# pca = PCA(n_components=1)
# Y = pca.fit_transform(Y)
# # PCA(copy=True, n_components=2, whiten=False)
# print('pca_value:',pca.explained_variance_ratio_)

kPCA = KernelPCA(kernel="rbf",n_components=3)
se = manifold.LocallyLinearEmbedding(n_components=1,n_neighbors=50)
X = kPCA.fit_transform(X)
# kPCA1 = KernelPCA(kernel="rbf",n_components=2)
# Y = kPCA1.fit_transform(Y)

# print(X.shape,Y.shape)
num_data, input_dim = X.shape

X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.5, random_state=42)
































# Augment the input with ones or zeros to indicate the required output dimension
X_augmented = np.vstack(
    (np.hstack((X1, np.zeros_like(X1))), np.hstack((X2, np.ones_like(X2))))
)

# Augment the Y data with ones or zeros that specify a likelihood from the list of likelihoods
Y_augmented = np.vstack(
    (np.hstack((Y1, np.zeros_like(Y1))), np.hstack((Y2, np.ones_like(Y2))))
)
# print(X_augmented)
# print(X_augmented.shape)


output_dim = 2  # Number of outputs
rank = 1  # Rank of W

# Base kernel
k = gpflow.kernels.Matern32(active_dims=[0])
#k = gpflow.kernels.Matern32()

# Coregion kernel
coreg = gpflow.kernels.Coregion(
    output_dim=output_dim, rank=rank,
    active_dims=[1]
)

kern = k * coreg

# This likelihood switches between Gaussian noise with different variances for each f_i:
lik = gpflow.likelihoods.SwitchedLikelihood(
    [gpflow.likelihoods.Gaussian(), gpflow.likelihoods.Gaussian()]
)

# now build the GP model as normal
m1 = gpflow.models.VGP((X_augmented, Y_augmented), kernel=kern, likelihood=lik)

# fit the covariance function parameters
#maxiter = reduce_in_tests(10000)
# gpflow.optimizers.Scipy().minimize(
#     m1.training_loss,
#     m1.trainable_variables,
#     #options=dict(maxiter=maxiter),
#     method="L-BFGS-B",
# )
Xtest = np.linspace(0,1,100)[:None]
y,Y_pred1 = m1.predict_y(np.hstack((Xtest, np.zeros_like(Xtest))))

inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(),X.max(),60).reshape(-1,1)
)
# m2 = gpflow.models.gpr.GPR_deprecated((X_train, Y_pred1), kernel=kern)
# # gpflow.optimizers.Scipy().minimize(
# #     m2.training_loss,
# #     m2.trainable_variables,
# #     #options=dict(maxiter=maxiter),
# #     method="L-BFGS-B",
# # )
# y,Y_pred2 = m2.predict_y(X_train)


#calculate metrics
R2 = r2_score(Y_augmented, Y_pred1, multioutput='raw_values')  # 拟合优度
R22 = 1 - np.sqrt(1 - R2)
Mse = mean_squared_error(Y_augmented, Y_pred1)  # 均方差
Mae = mean_absolute_error(Y_augmented, Y_pred1,
                          sample_weight=None,
                          multioutput='uniform_average')  # 平均绝对误差
Variance = explained_variance_score(Y_augmented, Y_pred1,
                                    sample_weight=None,
                                    multioutput='uniform_average')  # 可释方差得分
Meae = median_absolute_error(Y_augmented, Y_pred1)  # 中值绝对误差
print("R2_gpflow_test : " , R2)
print("R22 : " , R22)
print("Mse :",  Mse)
print("Rmse :",  np.sqrt(Mse))
print("Mae :",  Mae)
print("Variance :",  Variance)
print("Meae :",  Meae)