import math
import time

import numpy as np

import gpflow
import pandas as pd
#from gpflow.ci_utils import reduce_in_tests
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, explained_variance_score, \
    median_absolute_error
from sklearn.model_selection import train_test_split

dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\jiediansunhao-cjl.CSV',header=None)


dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

X = df2[:,0:column-1]
Y = df2[:,column-1:column]

#Y = Y.ravel()
# for battery_prediction
# x = df2[:,1:column-1]

# X = df2[:,0:6]
# X = np.delete(X, 3, 1)
# X = np.delete(X, 4, 1)
# print('x_shape',X.shape)
# Y = df2[:,6:7]
# Y = df2[:,7:8]
# Y = df2[:8:9]
# Y = df2[:,9:10]
# Y = df2[:,10:11]
from sklearn.preprocessing import scale, MinMaxScaler,RobustScaler,StandardScaler
# X = scale(X)
# Y = scale(Y)
scaler = StandardScaler()
X = scaler.fit_transform(X)
Y = scaler.fit_transform(Y)

X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.5, random_state=66)
num_data, input_dim = X.shape

model = gpflow.models.GPR(
    (X_train, Y_train),
    gpflow.kernels.SquaredExponential(),
)
print(X_test.shape)
print(Y_train.shape)
start1 = time.time()
_,y_pred = model.predict_f(X_test)
end1 = time.time()
posterior = model.posterior()
start2 = time.time()
posterior.predict_f(X_test)
end2 = time.time()
print(end1 - start1)
print("==============================")
print(end2 - start2)
# # calculate metrics
# R2 = r2_score(Y_test, y_pred, multioutput='raw_values')  # 拟合优度
# R22 = 1 - math.sqrt(1 - R2)
# Mse = mean_squared_error(Y_test, y_pred)  # 均方差
# Mae = mean_absolute_error(Y_test, y_pred,
#                           sample_weight=None,
#                           multioutput='uniform_average')  # 平均绝对误差
# Variance = explained_variance_score(Y_test, y_pred,
#                                     sample_weight=None,
#                                     multioutput='uniform_average')  # 可释方差得分
# Meae = median_absolute_error(Y_test, y_pred)  # 中值绝对误差
# # if (R2 > 0.9100):
# #     print('OK!',R2)
# #     np.savetxt('y/y.csv',y_test,delimiter=',')
# #     np.savetxt('y/y_pred.csv',y_pred,delimiter=',')
#
# print("R2 :%.4f" % R2)
# print("R22 :%.4f" % R22)
# print("Mse :%.4f" % Mse)
# print("Rmse :%.4f" % math.sqrt(Mse))
# print("Mae :%.4f" % Mae)
# print("Variance :%.4f" % Variance)
# print("Meae :%.4f" % Meae)