import math

import pandas as pd
import tensorflow as tf
import gpflow
import gpflux
import numpy as np
import matplotlib.pyplot as plt
from sklearn import manifold
from sklearn.decomposition import KernelPCA
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, explained_variance_score, \
    median_absolute_error
from sklearn.model_selection import train_test_split
from tqdm import tqdm

import tensorflow_probability as tfp
from sklearn.neighbors import KernelDensity
tf.keras.backend.set_floatx("float64")

dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\multi792.csv',header=None)


dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

X = df2[:,0:column-4]
Y = df2[:,column-4:column]
# for battery_prediction
# x = df2[:,1:column-1]

# X = df2[:,0:6]
# X = np.delete(X, 3, 1)
# X = np.delete(X, 4, 1)
# print('x_shape',X.shape)
# Y = df2[:,6:7]
# Y = df2[:,7:8]
# Y = df2[:8:9]
# Y = df2[:,9:10]
# Y = df2[:,10:11]
from sklearn.preprocessing import scale, MinMaxScaler
# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)
# X = scale(X)
# Y = scale(Y)


# kPCA = KernelPCA(kernel="poly",n_components=4)
# se = manifold.LocallyLinearEmbedding(n_components=1,n_neighbors=50)
# X = kPCA.fit_transform(X)
# kPCA1 = KernelPCA(kernel="rbf",n_components=2)
# Y = kPCA1.fit_transform(Y)


# from sklearn.decomposition import PCA
# pca = PCA(n_components=2)
# pca.fit(X)
# # PCA(copy=True, n_components=2, whiten=False)
# print('pca_value:',pca.explained_variance_ratio_)


# print(X.shape,Y.shape)
num_data, input_dim = X.shape
print(X.shape)
#print("num_data: "+num_data+"input_dim: "+input_dim)
X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.2, random_state=66)

num_data = len(X)
print("num_data: "+str(num_data))
print(X.min(),X.max())#0.0,1.0
num_inducing = 20
output_dim = Y_train.shape[1]
print(output_dim)

Matern52_kernel = gpflow.kernels.Matern52() + gpflow.kernels.SquaredExponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
# inducing_variable = gpflow.inducing_variables.MultioutputInducingVariables(
#     np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
# )
gp_layer_Matern52 = gpflux.layers.GPLayer(
    Matern52_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
likelihood_layer = gpflux.layers.LikelihoodLayer(gpflow.likelihoods.Gaussian())  # noqa: E231
dgp = gpflux.models.DeepGP([tf.keras.layers.Dense(1, activation="linear"),gp_layer_Matern52], likelihood_layer)
#model = dgp.as_training_model()
likelihood = gpflow.likelihoods.Gaussian(0.01)

# So that Keras can track the likelihood variance, we need to provide the likelihood as part of a "dummy" layer:
likelihood_container = gpflux.layers.TrackableLayer()
likelihood_container.likelihood = likelihood
model1 = tf.keras.Sequential(
    [



        tf.keras.layers.Dense(1, activation="linear"),
        gp_layer_Matern52,
gp_layer_Matern52,
gp_layer_Matern52,


        likelihood_container,  # no-op, for discovering trainable likelihood parameters
    ]
)
loss = gpflux.losses.LikelihoodLoss(likelihood)


#model1.compile(loss,tf.optimizers.Adam(learning_rate=0.1))
model1.compile(loss=loss, optimizer="adam")
hist = model1.fit(X_train, Y_train, epochs=1000, verbose=0)
y_pred=model1.predict(X_test)
y_test = Y_test
# calculate metrics
R2_list = []
R22_list = []
Mse_list = []
Mae_list = []
Variance_list = []
Meae_list = []

for i in range(0,output_dim):
    R2 = r2_score(y_test[i], y_pred[i], multioutput='raw_values')  # 拟合优度
    R22 = 1 - tf.sqrt(1 - R2)
    Mse = mean_squared_error(y_test[i], y_pred[i])  # 均方差
    Mae = mean_absolute_error(y_test[i], y_pred[i],
                              sample_weight=None,
                              multioutput='uniform_average')  # 平均绝对误差
    Variance = explained_variance_score(y_test[i], y_pred[i],
                                        sample_weight=None,
                                        multioutput='uniform_average')  # 可释方差得分
    Meae = median_absolute_error(y_test[i], y_pred[i])  # 中值绝对误差
# R2 = r2_score(y_test, y_pred, multioutput='raw_values')  # 拟合优度
# R22 = 1 - tf.sqrt(1 - R2)
# Mse = mean_squared_error(y_test, y_pred)  # 均方差
# Mae = mean_absolute_error(y_test, y_pred,
#                           sample_weight=None,
#                           multioutput='uniform_average')  # 平均绝对误差
# Variance = explained_variance_score(y_test, y_pred,
#                                     sample_weight=None,
#                                     multioutput='uniform_average')  # 可释方差得分
# Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差
    R2_list.append(R2)
    R22_list.append(R22)
    Mse_list.append(Mse)
    Mae_list.append(Mae)
    Variance_list.append(Variance)
    Meae_list.append(Meae)
    print("R2_gpflux_test : " , R2)
    print("R22 : " , R22)
    print("Mse :",  Mse)
    print("Rmse :",  np.sqrt(Mse))
    print("Mae :",  Mae)
    print("Variance :",  Variance)
    print("Meae :",  Meae)
    print('=====================================')

print('R2_mean: ', np.array(R2_list).mean())
print('R22_mean: ',np.array(R22_list).mean())
print('Mse_mean: ',np.array(Mse_list).mean())
print('Mae_mean: ',np.array(Mae_list).mean())
print('Variance_mean: ',np.array(Variance_list).mean())
print('Meae_mean: ',np.array(Meae_list).mean())
