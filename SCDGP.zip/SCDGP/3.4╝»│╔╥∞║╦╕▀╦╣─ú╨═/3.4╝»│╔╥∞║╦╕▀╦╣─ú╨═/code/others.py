# -*- coding: utf-8 -*-
"""
Created on Sat Jun 23 18:27:43 2018

@author: gh
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Jun  2 15:27:52 2018

@author: gh
"""
import math
#from mlxtend.regressor import StackingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.svm import SVR
#import matplotlib.pyplot as plt
import numpy as np
#import pods
from math import sqrt
#import numpy as np
#import GPy
#from pylab import *
#from sys import path
np.random.seed(42)
import csv
#import deepgp
#import sklearn
#from sklearn import preprocessing
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Lasso
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import explained_variance_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import median_absolute_error
from sklearn.metrics import r2_score

# 生成一个样本数据集
#np.random.seed(1)
#X = np.sort(5 * np.random.rand(40, 1), axis=0)
#y = np.sin(X).ravel()
#y[::5] += 3 * (0.5 - np.random.rand(8))

# with open('data/housing_csv.csv','r') as f:
with open( 'E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\dianji_cjl.CSV') as f:

	reader = csv.reader(f)
	data=[]
	for i in reader:
		data += [[float(j) for j in i]]
t=np.array(data)
data = np.swapaxes(t,0,1)
# with open('data/auto_csv.csv','r') as f:
# 	reader = csv.reader(f)
# 	data=[]
# 	for i in reader:
# 		data += [[float(j) for j in i]]
# t=np.array(data)
# data = np.swapaxes(t,0,1)

#data = sklearn.preprocessing.normalize(data, norm='l2')

X = np.swapaxes(data[:7],0,1)
y = np.swapaxes(data[7:],0,1)
from scipy.stats import zscore
X = zscore(X)
y = zscore(y)
#y = reduce(operator.add, y1)
y = y.ravel()

#模型保存
#from sklearn.externals import joblib
#import os
#os.chdir("workspace/model_save")

####3.1决策树回归####
from sklearn import tree
model_DecisionTreeRegressor = tree.DecisionTreeRegressor()
####3.2线性回归####
from sklearn import linear_model
model_LinearRegression = linear_model.LinearRegression()
####3.3SVM回归####
from sklearn import svm
model_SVR = svm.SVR(kernel='linear',gamma=1e-10,C=10)
# model_SVR = svm.SVR(kernel='rbf', gamma=1e-10, C=10)
####3.4KNN回归####
from sklearn import neighbors
model_KNeighborsRegressor = neighbors.KNeighborsRegressor(n_neighbors=1)
####3.5随机森林回归####
from sklearn import ensemble
model_RandomForestRegressor = ensemble.RandomForestRegressor()#这里使用20个决策树
####3.6Adaboost回归####
from sklearn import ensemble
model_AdaBoostRegressor = ensemble.AdaBoostRegressor()#这里使用50个决策树
####3.7GBRT回归####
from sklearn import ensemble
model_GradientBoostingRegressor = ensemble.GradientBoostingRegressor()#这里使用100个决策树
####3.8Bagging回归####
from sklearn.ensemble import BaggingRegressor
model_BaggingRegressor = BaggingRegressor()
####3.9ExtraTree极端随机树回归####
from sklearn.tree import ExtraTreeRegressor
model_ExtraTreeRegressor = ExtraTreeRegressor()

ridge = Ridge(random_state=1, alpha = 20.0)
lasso = Lasso(random_state=1, alpha = 20.0)

for clf, label in zip([model_DecisionTreeRegressor, model_LinearRegression, model_KNeighborsRegressor,
                       model_RandomForestRegressor, model_AdaBoostRegressor, model_GradientBoostingRegressor,
                       model_BaggingRegressor, model_ExtraTreeRegressor, ridge, lasso],
                      ['model_DecisionTreeRegressor',
                       'model_LinearRegression',


                       'model_KNeighborsRegressor',
                       'model_RandomForestRegressor',
                       'model_AdaBoostRegressor',
                       'model_GradientBoostingRegressor',
                       'model_BaggingRegressor',
                       'model_ExtraTreeRegressor',
                       'ridge',
                       'lasso']):

    
   
    Y_pred = cross_val_predict(clf, X, y, cv=5)
    print(label)
    R2 = r2_score(y, Y_pred, multioutput='raw_values')             #拟合优度
    R22 = 1-math.sqrt(1-R2)
    Mse = mean_squared_error(y,Y_pred)                                 #均方差
    Mae = mean_absolute_error(y,Y_pred,
                        sample_weight=None,
                        multioutput='uniform_average')                              #平均绝对误差
    Variance =  explained_variance_score(y, Y_pred,
                              sample_weight=None,
                               multioutput='uniform_average')                        #可释方差得分
    Meae =  median_absolute_error(y, Y_pred)                       #中值绝对误差
    print ("R2 :%.4f" %  R2)
    print ("R22 :%.4f" %  R22)
    print ("Mse :%.4f" %  Mse)
    print ("Rmse :%.4f" %  math.sqrt(Mse))
    # print ("Mae :%.4f" %  Mae)
    # print ("Variance :%.4f" %  Variance)
    # print ("Meae :%.4f" %  Meae)
    # np.savetxt(''+label+'.csv', Y_pred, delimiter = ',')

    # fig, ax = plt.subplots()
    # ax.scatter(y, Y_pred, edgecolors=(0, 0, 0))
    # ax.plot([y.min(), y.max()], [y.min(), y.max()], 'k--', lw=4)
    # ax.set_xlabel('Measured')
    # ax.set_ylabel('Predicted')
    # plt.show()
#其他评判标准
# np.savetxt('y.csv', y, delimiter = ',')


#with plt.style.context(('seaborn-whitegrid')):
#    plnn  t.scatter(X, y, c='lightgray')
#    plt.plot(X, stregr.predict(X), c='darkgreen', lw=2)

#plt.show()

#clf = joblib.load("train_model.m")  调用模型
#clf.predit(test_X，test_y)