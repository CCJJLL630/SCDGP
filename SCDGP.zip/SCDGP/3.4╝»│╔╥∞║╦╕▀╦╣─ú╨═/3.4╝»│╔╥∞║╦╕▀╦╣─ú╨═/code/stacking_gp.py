#import gpflux

from sklearn import svm
from sklearn.linear_model import RidgeCV, LassoCV
from sklearn.tree import DecisionTreeRegressor,ExtraTreeRegressor
from sklearn.ensemble import RandomForestRegressor,AdaBoostRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, DotProduct, ExpSineSquared
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import StackingRegressor,BaggingRegressor
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold,cross_val_score
import csv
import math
import numpy as np
import tensorflow as tf
import gpflow

#from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
# from tensorflow.keras.models import Sequential
# from tensorflow.keras.layers.core import Dense, Dropout, Activation
# from tensorflow.keras.optimizers import SGD
# from tensorflow.keras.utils import np_utils
# from tensorflow.keras.layers.advanced_activations import LeakyReLU, PReLU
# from tensorflow.keras.layers.normalization import BatchNormalization
# from tensorflow.keras.regularizers import l1, l2, l1l2, activity_l2

#import stackingModel
import KerasRegTest
import gpflow_gp
import Matern_32_kernel
import RQ_kernel
import Matern_52_kernel
import Exp_kernel

import stacking


with open('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\jiediansunhao.csv', 'r') as f:
    reader = csv.reader(f)
    data = []
    for i in reader:
        data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)
X = np.swapaxes(data[:6], 0, 1)
y = np.swapaxes(data[6:], 0, 1)
# with open('data/2000.csv', 'r') as f:
# 	reader = csv.reader(f)
# 	data = []
# 	for i in reader:
# 		data += [[float(j) for j in i]]
# t = np.array(data)
# data = np.swapaxes(t, 0, 1)
# X = np.swapaxes(data[:11], 0, 1)
# y = np.swapaxes(data[11:], 0, 1)
y = y.ravel()

from sklearn.preprocessing import StandardScaler
# X = StandardScaler().fit_transform(X)
# y = StandardScaler().fit_transform(y)

# def rf_cv(n_estimators, min_samples_split, max_features, max_depth):
# 	val = cross_val_score(
# 		RandomForestRegressor(n_estimators=int(n_estimators),
# 			min_samples_split=int(min_samples_split),
# 			max_features=min(max_features, 0.999), # float
# 			max_depth=int(max_depth),
# 			 random_state=2
# 		),
# 		X, y, scoring='r2', cv=5
# 	).mean()
# 	return val

# rf_bo = BayesianOptimization(
#         rf_cv,
#         {'n_estimators': (10, 250),
#         'min_samples_split': (2, 25),
#         'max_features': (0.1, 0.999),
#         'max_depth': (5, 15)}
#     )

model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)
ridge = RidgeCV()
lasso = LassoCV()

kfold = KFold(n_splits=5)

R2_l = []
Mse_l = []
Rmse_l = []
Y_Pred = []
Y_Test = []

# def baseline_model():
#   model = tf.keras.Sequential()
#   model.add(tf.keras.layers.Dense(13, input_dim=13, kernel_initializer='normal', activation='relu'))
#   model.add(tf.keras.layers.Dense(1, kernel_initializer='normal'))
#   #model.compile(loss='mean_squared_error', optimizer='adam')
#   return model




for train, test in kfold.split(X):
    X_train = np.array(X)[train]
    y_train = np.array(y)[train]
    # print(X_train,y_train)
    X_test = np.array(X)[test]
    y_test = np.array(y)[test]
    # print(X_test)
    kernel1 = RationalQuadratic()
    kernel2 = Matern()
    kernel3 = RBF()
    kernel4 = RationalQuadratic() + Matern()
    kernel5 = Matern() + RBF()
    # kernel6 = RBF()+RationalQuadratic()
    gp1 = GaussianProcessRegressor(kernel=kernel1)
    gp2 = GaussianProcessRegressor(kernel=kernel2)
    gp3 = GaussianProcessRegressor(kernel=kernel3)
    gp4 = GaussianProcessRegressor(kernel=kernel4)
    gp5 = GaussianProcessRegressor(kernel=kernel5)
    # model = KerasRegressor(build_fn = baseline_model,epochs=100,batch_size=5,verbose=0)
    # model._estimator_type = "regressor"
    # model1 = KerasRegTest.r2
    model_matern32 = Matern_32_kernel.model_Matern32_kernel
    model_matern52 = Matern_52_kernel.model_Matern52_kernel
    model_RQ = RQ_kernel.model_RQ_kernel
    model_Exp = Exp_kernel.model_Exp_kernel




    #estimators = [('gp1',gp2), ('gp2',gp1), ('gp3',gp4), ('gp4',gp5),('gp6',gp6)]
    estimators = [('gp1', gp2), ('gp2', gp1), ('gp3', gp4), ('gp4', gp5)]
    estimators2 = [('gp1', gp2), ('gp2', gp1), ('gp3', gp3),('gp4',gp4)]
    #estimators2 = [('gp6',gp6), ('gp6',gp6), ('gp6',gp6), ('gp6',gp6)]
    estimators3 = [('rf',RandomForestRegressor()),('gb',GradientBoostingRegressor()),
                   ('ad',AdaBoostRegressor()),('ex',ExtraTreeRegressor())]

    #reg = StackingRegressor(estimators=estimators2, final_estimator=model_SVR)
    from sklearn.linear_model import RidgeCV,LassoCV

    final_layer = StackingRegressor(
    estimators = [('gp2',gp2),
    			  ('gp3',gp3),
    			  ('gp4',gp4),
    			 ],
    final_estimator = model_SVR)

    # final_layer = StackingRegressor(
    # estimators = [#('gp',gp2),
    #                ('RQ',model_RQ),
    #                 ('Exp',model_Exp),
    #               ('matern52',model_matern52),
    #               ('matern32',model_matern32),
    #
    #               ],
    # final_estimator = model_rbfsvr)
    _3reg = StackingRegressor(estimators=estimators3,final_estimator=final_layer)

    rfreg = RandomForestRegressor()

    kreg = KNeighborsRegressor()
    greg = GradientBoostingRegressor()
    adreg = AdaBoostRegressor()
    breg = BaggingRegressor(base_estimator=gp2,n_estimators=20)
    treg = DecisionTreeRegressor()
    ereg = ExtraTreeRegressor()



    _3reg.fit(X_train, y_train)
    Y_predicted = _3reg.predict(X_test)


    # likelihood = gpflow.likelihoods.Gaussian(0.1)
    # loss = gpflux.losses.LikelihoodLoss(likelihood)
    # model.compile(loss=loss, optimizer="adam")
    # hist = model.fit(X_train, y_train, epochs=1000, verbose=0)
    # y_pred = model.predict(X_test)

    R2 = r2_score(y_test, Y_predicted)
    Mse = mean_squared_error(y_test, Y_predicted)
    Rmse = math.sqrt(Mse)
    R2_l.append(R2)
    Mse_l.append(Mse)
    Rmse_l.append(Rmse)
    print("R233 :%.4f" % R2)
    print("Mse :%.4f" % Mse)
    print("Rmse :%.4f" % math.sqrt(Mse))















    # gp5.fit(X_train, y_train)
    # Y_predicted = gp5.predict(X_test)
    # R2 = r2_score(y_test, Y_predicted)
    # Mse = mean_squared_error(y_test, Y_predicted)
    # print(Mse)
    # Rmse = math.sqrt(Mse)
    # R2_l.append(R2)
    # Mse_l.append(Mse)
    # Rmse_l.append(Rmse)

print('R2:',np.mean(R2_l))
print('Mse:',np.mean(Mse_l))
print('Rmse:',np.mean(Rmse_l))
