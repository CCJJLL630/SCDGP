from sklearn import svm
from sklearn.linear_model import RidgeCV, LassoCV,LinearRegression
from sklearn.tree import DecisionTreeRegressor,ExtraTreeRegressor
from sklearn.ensemble import RandomForestRegressor,AdaBoostRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, DotProduct, ExpSineSquared
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import StackingRegressor,BaggingRegressor
from sklearn.model_selection import cross_val_predict,RandomizedSearchCV
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold, cross_val_score
# from bayes_opt import BayesianOptimization
import csv
import math
import numpy as np
# with open('data/housing_csv.csv', 'r') as f:
with open('D:/CjlNoFile/组会文件/深度高斯过程/3.4集成异核高斯模型/3.4集成异核高斯模型/data/7-2-1.csv', 'r') as f:
	reader = csv.reader(f)
	data = []
	for i in reader:
		data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)

X = np.swapaxes(data[:5], 0, 1)
y = np.swapaxes(data[5:], 0, 1)
# with open('data/jieguo700.csv', 'r') as f:
# 	reader = csv.reader(f)
# 	data = []
# 	for i in reader:
# 		data += [[float(j) for j in i]]
# t = np.array(data)
# data = np.swapaxes(t, 0, 1)
# X = np.swapaxes(data[:4], 0, 1)
# y = np.swapaxes(data[4:], 0, 1)

from sklearn.preprocessing import StandardScaler,scale
from scipy.stats import zscore
# X = scale(X)
# y = scale(y)
# X = StandardScaler().fit_transform(X)
# y = StandardScaler().fit_transform(y)
# X = zscore(X)
# y = zscore(y)
y = y.ravel()


model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)


kernel1 = RationalQuadratic()
kernel2 = Matern()
kernel3 = RBF()
kernel4 = RationalQuadratic() + Matern()
kernel5 = Matern() + RBF()
# kernel6 = RBF()+RationalQuadratic()
gp1 = GaussianProcessRegressor(kernel=kernel1)
gp2 = GaussianProcessRegressor(kernel=kernel2)
gp3 = GaussianProcessRegressor(kernel=kernel3)
gp4 = GaussianProcessRegressor(kernel=kernel4)
gp5 = GaussianProcessRegressor(kernel=kernel5)
# gp6 = GaussianProcessRegressor(kernel=kernel6)

estimators3 = [('rf',RandomForestRegressor(n_estimators=20)),('gb',GradientBoostingRegressor(n_estimators=50)),
			  ('ad',AdaBoostRegressor(n_estimators=20)),('ex',ExtraTreeRegressor())]


final_layer = StackingRegressor(
estimators = [('gp1', gp1),('gp2', gp2),('gp3',gp3)],final_estimator=model_SVR
)
_3reg = StackingRegressor(estimators=estimators3, final_estimator=final_layer)


params = {
		'final_estimator__gp1__alpha':[1e-6,1e-5,1e-3,1,10],
		'final_estimator__gp2__alpha':[1e-6,1e-5,1e-3,1,10],
		'final_estimator__gp3__alpha': [1e-6, 1e-5, 1e-3,1e-2,1,10],
		# 'final_estimator__gp5__alpha': [1e-5, 1e-3, 1, 10],
		'final_estimator__final_estimator__C': [0.01,0.1,1,10,100],
		'final_estimator__final_estimator__gamma': [0.01, 0.1, 1,10,100],
		# 'final_estimator__final_'
		# 'final_estimator__gp5__alpha': [1e-6, 1e-5, 1e-3],
	}

grid = RandomizedSearchCV(estimator=_3reg,cv=2,param_distributions=params,
							  scoring='r2',n_iter=20,
							  n_jobs=-1)




Y_pred =cross_val_predict(grid, X,y,cv=5)
# print(grid.best_score_)
# print(grid.best_params_)
# print(grid.best_estimator_)
R2 = r2_score(y, Y_pred, multioutput='raw_values')             #拟合优度
R22 = 1-math.sqrt(1-R2)
Mse = mean_squared_error(y,Y_pred)                                 #均方差
print ("R2 :%.4f" %  R2)
print ("R22 :%.4f" %  R22)
print ("Mse :%.4f" %  Mse)
print ("Rmse :%.4f" %  math.sqrt(Mse))

	


# y_pred = np.array(y_pred)
# y_test = np.array(y_test)
# y_pred =y_pred.reshape(-1, 1)
# y_test = y_test.reshape(-1, 1)

# np.savetxt('three/std/y_pred'+'three2'+'.csv', y_pred, delimiter=',', fmt='%s')
# np.savetxt('three/std/y_test'+'three2'+'.csv', y_test, delimiter=',', fmt='%s')

