from sklearn import svm
from sklearn.linear_model import RidgeCV, LassoCV,LinearRegression
from sklearn.tree import DecisionTreeRegressor,ExtraTreeRegressor
from sklearn.ensemble import RandomForestRegressor,AdaBoostRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, DotProduct, ExpSineSquared
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import StackingRegressor,BaggingRegressor
from sklearn.model_selection import cross_val_predict,RandomizedSearchCV
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold, cross_val_score
# from bayes_opt import BayesianOptimization
import csv
import math
import numpy as np
with open('data/carbon/soft/soft-y3.csv', 'r') as f:
	reader = csv.reader(f)
	data = []
	for i in reader:
		data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)

X = np.swapaxes(data[:5], 0, 1)
y = np.swapaxes(data[5:], 0, 1)
# with open('data/jieguo700.csv', 'r') as f:
# 	reader = csv.reader(f)
# 	data = []
# 	for i in reader:
# 		data += [[float(j) for j in i]]
# t = np.array(data)
# data = np.swapaxes(t, 0, 1)
# X = np.swapaxes(data[:4], 0, 1)
# y = np.swapaxes(data[4:], 0, 1)

from sklearn.preprocessing import StandardScaler,scale
from scipy.stats import zscore
# X = scale(X)
# y = scale(y)
# X = StandardScaler().fit_transform(X)
# y = StandardScaler().fit_transform(y)
# X = zscore(X)
# y = zscore(y)
y = y.ravel()


model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=1)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)


kernel1 = RationalQuadratic()
kernel2 = Matern()
kernel3 = RBF()
kernel4 = RationalQuadratic() + Matern()
kernel5 = Matern() + RBF()
# kernel6 = RBF()+RationalQuadratic()
gp1 = GaussianProcessRegressor(kernel=kernel1,alpha=1)
gp2 = GaussianProcessRegressor(kernel=kernel2,alpha=1e-5)
gp3 = GaussianProcessRegressor(kernel=kernel3,alpha=1e-6)
gp4 = GaussianProcessRegressor(kernel=kernel4)
gp5 = GaussianProcessRegressor(kernel=kernel5)
# gp6 = GaussianProcessRegressor(kernel=kernel6)

estimators3 = [('rf',RandomForestRegressor(n_estimators=20)),('gb',GradientBoostingRegressor(n_estimators=50)),
			  ('ad',AdaBoostRegressor(n_estimators=20)),('ex',ExtraTreeRegressor())]


final_layer = StackingRegressor(
estimators = [('gp1', gp1),('gp2', gp2),('gp3',gp3)],final_estimator=model_SVR
)
_3reg = StackingRegressor(estimators=estimators3, final_estimator=final_layer)


kfold = KFold(n_splits=5,random_state=42,shuffle=True)
R2_l = []
Mse_l = []
Rmse_l = []
Y_Pred = []
Y_Test = []
for train, test in kfold.split(X):
	X_train = np.array(X)[train]
	y_train = np.array(y)[train]
	# print(X_train,y_train)
	X_test = np.array(X)[test]
	y_test = np.array(y)[test]
	# print(X_test)

	params = {
		'final_estimator__gp1__alpha': [1e-6, 1e-5, 1e-3, 1],
		'final_estimator__gp2__alpha': [1e-6, 1e-5, 1e-3, 1],
		'final_estimator__gp3__alpha': [1e-6, 1e-5, 1e-3, 1e-2],
		# 'final_estimator__gp5__alpha': [1e-5, 1e-3, 1, 10],
		'final_estimator__final_estimator__C': [0.01, 0.1,1, 100],
		'final_estimator__final_estimator__gamma': [0.01, 0.1,1, 100],
		# 'final_estimator__final_'
		# 'final_estimator__gp5__alpha': [1e-6, 1e-5, 1e-3],
	}
	grid = RandomizedSearchCV(estimator=_3reg, cv=2, param_distributions=params,
							  scoring='neg_mean_squared_error', n_iter=20,
							  n_jobs=-1)

	grid.fit(X_train, y_train)
	Y_predicted =grid.predict(X_test)
	# print('best parameters:',grid.best_estimator_)
	Mse = mean_squared_error(y_test, Y_predicted)
	print(Mse)
	Y_Pred.append(Y_predicted.tolist())
	Y_Test.append(y_test.tolist())
	

y_pred = sum(Y_Pred, [])
y_test = sum(Y_Test, [])
y_pred = np.array(y_pred)
y_test = np.array(y_test)
y_pred =y_pred.reshape(-1, 1)
y_test = y_test.reshape(-1, 1)
R2 = r2_score(y_test, y_pred, multioutput='raw_values')
Mse = mean_squared_error(y_test,y_pred)
Rmse = math.sqrt(Mse)
# np.savetxt('three/std/y_pred'+'three2'+'.csv', y_pred, delimiter=',', fmt='%s')
# np.savetxt('three/std/y_test'+'three2'+'.csv', y_test, delimiter=',', fmt='%s')
print('R2:',R2)
# print('R2:',np.mean(R2_l))
print('Mse:',Mse)
print('Rmse:',Rmse)
