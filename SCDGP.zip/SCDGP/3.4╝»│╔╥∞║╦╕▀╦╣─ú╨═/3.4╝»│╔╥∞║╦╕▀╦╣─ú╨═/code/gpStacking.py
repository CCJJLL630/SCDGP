import xgboost
from keras.layers import Flatten, Dense, Dropout
from sklearn import svm
from sklearn.linear_model import RidgeCV, LassoCV
from sklearn.tree import DecisionTreeRegressor,ExtraTreeRegressor
from sklearn.ensemble import RandomForestRegressor,AdaBoostRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, DotProduct, ExpSineSquared
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import StackingRegressor,BaggingRegressor
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold,cross_val_score
import csv
import math
import numpy as np
import gpflow
from xgboost import XGBRegressor
import lightgbm as lgb
import catboost as cb
import tensorflow as tf

with open('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data/jieguo700.csv', 'r') as f:
	reader = csv.reader(f)
	data = []
	for i in reader:
		data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)
X = np.swapaxes(data[:4], 0, 1)
y = np.swapaxes(data[4:], 0, 1)
# with open('data/2000.csv', 'r') as f:
# 	reader = csv.reader(f)
# 	data = []
# 	for i in reader:
# 		data += [[float(j) for j in i]]
# t = np.array(data)
# data = np.swapaxes(t, 0, 1)
# X = np.swapaxes(data[:11], 0, 1)
# y = np.swapaxes(data[11:], 0, 1)
y = y.ravel()

from sklearn.preprocessing import StandardScaler
# X = StandardScaler().fit_transform(X)
# y = StandardScaler().fit_transform(y)

# def rf_cv(n_estimators, min_samples_split, max_features, max_depth):
# 	val = cross_val_score(
# 		RandomForestRegressor(n_estimators=int(n_estimators),
# 			min_samples_split=int(min_samples_split),
# 			max_features=min(max_features, 0.999), # float
# 			max_depth=int(max_depth),
# 			 random_state=2
# 		),
# 		X, y, scoring='r2', cv=5
# 	).mean()
# 	return val

# rf_bo = BayesianOptimization(
#         rf_cv,
#         {'n_estimators': (10, 250),
#         'min_samples_split': (2, 25),
#         'max_features': (0.1, 0.999),
#         'max_depth': (5, 15)}
#     )

model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)
ridge = RidgeCV()
lasso = LassoCV()

kfold = KFold(n_splits=5)

R2_l = []
Mse_l = []
Rmse_l = []
Y_Pred = []
Y_Test = []
for train, test in kfold.split(X):
	X_train = np.array(X)[train]
	y_train = np.array(y)[train]
	# print(X_train,y_train)
	X_test = np.array(X)[test]
	y_test = np.array(y)[test]
	# print(X_test)
	kernel1 = RationalQuadratic()
	kernel2 = Matern()
	kernel3 = RBF()
	kernel4 = RationalQuadratic() + Matern()
	kernel5 = Matern() + RBF()
	# kernel6 = RBF()+RationalQuadratic()
	gp1 = GaussianProcessRegressor(kernel=kernel1)
	gp2 = GaussianProcessRegressor(kernel=kernel2)
	gp3 = GaussianProcessRegressor(kernel=kernel3)
	gp4 = GaussianProcessRegressor(kernel=kernel4)
	gp5 = GaussianProcessRegressor(kernel=kernel5)

	model1 = tf.keras.models.Sequential([

		Dense(512, activation=tf.nn.relu),

		Dense(256, activation=tf.nn.relu),

		Dense(128, activation=tf.nn.relu),

		Dense(64, activation=tf.nn.relu),

		Dense(1, activation=tf.nn.softmax)
	])

	# gp6 = GaussianProcessRegressor(kernel=kernel6)
	estimators = [('gp1',gp2), ('gp2',gp1), ('gp3',gp4), ('gp4',gp5)]
	estimators2 = [('gp1', gp2), ('gp2', gp1), ('gp3', gp3),('gp4',gp4)]
	# estimators3 = [('rf',RandomForestRegressor()),('gb',GradientBoostingRegressor()),
	# 			   ('ad',AdaBoostRegressor()),('ex',ExtraTreeRegressor())]
	estimators3 = [('rf', xgboost.XGBRegressor()), ('gb', lgb.LGBMRegressor()),
				   ('ad', cb.CatBoostRegressor()), ('ex', cb.CatBoostRegressor())]

	reg = StackingRegressor(estimators=estimators2, final_estimator=model_SVR)
	from sklearn.linear_model import RidgeCV,LassoCV

	final_layer = StackingRegressor(
	estimators = [('gp1', gp1),
				  ('gp2', gp2),
				  ('gp3',gp3)],
	final_estimator = model_SVR)
	_3reg = StackingRegressor(estimators=estimators3, final_estimator=final_layer)

	rfreg = RandomForestRegressor()
	kreg = KNeighborsRegressor()
	greg = GradientBoostingRegressor()
	adreg = AdaBoostRegressor()
	breg = BaggingRegressor(base_estimator=gp2,n_estimators=20)
	treg = DecisionTreeRegressor()
	ereg = ExtraTreeRegressor()

	_3reg.fit(X_train, y_train)
	Y_predicted = _3reg.predict(X_test)
	model1.compile(loss="mse", optimizer="adam")
	model1.fit(X_train, y_train)

	y_pred_ann = model1.predict(X_test)
	# gp5.fit(X_train, y_train)
	# Y_predicted = gp5.predict(X_test)
	R2 = r2_score(y_test, Y_predicted)
	Mse = mean_squared_error(y_test, Y_predicted)
	print('R2: ',R2)
	print('Mse: ',Mse)
	Rmse = math.sqrt(Mse)
	print('Rmse: ',Rmse)
	R2_ann = r2_score(y_test, y_pred_ann)
	Mse_ann = mean_squared_error(y_test, y_pred_ann)
	print('R2-ann: ', R2_ann)
	print('Mse-ann: ', Mse_ann)
	Rmse_ann = math.sqrt(Mse_ann)
	print('Rmse-ann: ', Rmse_ann)
	R2_l.append(R2)
	Mse_l.append(Mse)
	Rmse_l.append(Rmse)

print('R2:',np.mean(R2_l))
print('Mse:',np.mean(Mse_l))
print('Rmse:',np.mean(Rmse_l))
