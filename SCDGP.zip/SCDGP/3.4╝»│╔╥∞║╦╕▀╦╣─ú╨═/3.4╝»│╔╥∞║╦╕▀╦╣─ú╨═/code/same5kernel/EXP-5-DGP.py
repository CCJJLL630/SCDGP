import math
import time

import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn import svm, manifold
from sklearn.decomposition import KernelPCA
from xgboost import XGBRegressor
from sklearn.ensemble \
    import RandomForestRegressor, AdaBoostRegressor, GradientBoostingRegressor, StackingRegressor,HistGradientBoostingRegressor

from sklearn.tree import ExtraTreeRegressor, DecisionTreeRegressor
import lightgbm as lgb
np.random.seed(42)
import gpflow
import gpflux

from gpflow.config import default_float
from sklearn.metrics import median_absolute_error, explained_variance_score, mean_absolute_error, mean_squared_error, \
    r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import csv
tf.keras.backend.set_floatx("float64")

# dataframe = pd.read_csv("data/jiedianchangshu.csv", header=None)
# dataframe = pd.read_csv("data/covid-Italy.csv", header=None)
# dataframe = pd.read_excel("data/25_soc2000.xls", header=0)
#dataframe = pd.read_csv("data/jiedian-cjl.csv", header=None)
# dataframe = pd.read_csv("data/bancao.csv", header=None)
# dataframe = pd.read_csv("data/multi792.csv", header=None)
# dataframe = pd.read_csv("data/battery4900.csv", header=None)
# dataframe = pd.read_csv("data/battery12000.csv", header=None)
# dataframe = pd.read_csv("data/battery_origin.csv", header=None)
# dataframe = dataframe.sample(frac=0.1, replace=False, random_state=42)
# dataframe = pd.read_csv("data/pushi/CBM.csv", header=None)
# dataframe = pd.read_csv("data/pushi/concrete.csv", header=None)
# dataframe = pd.read_csv("data/pushi/kin8nm.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-red.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-white.csv", header=None)
# dataframe = pd.read_csv("data/pushi/yacht.csv", header=None)
#dataframe = pd.read_csv("data/jiediansunhao.csv", header=None)
#dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\jiediansunhao-cjl.CSV',header=None)
dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\\dianji_cjl.CSV',header=None)

dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

X = df2[:,0:column-1]
Y = df2[:,column-1:column]
#Y = Y.ravel()
# for battery_prediction
# x = df2[:,1:column-1]

# X = df2[:,0:6]
# X = np.delete(X, 3, 1)
# X = np.delete(X, 4, 1)
# print('x_shape',X.shape)
# Y = df2[:,6:7]
# Y = df2[:,7:8]
# Y = df2[:8:9]
# Y = df2[:,9:10]
# Y = df2[:,10:11]
from sklearn.preprocessing import scale, MinMaxScaler,RobustScaler,StandardScaler
# X = scale(X)
# Y = scale(Y)
scaler = StandardScaler()
X = scaler.fit_transform(X)
Y = scaler.fit_transform(Y)
# mm = MinMaxScaler()
# X = mm.fit_transform(X)
# Y = mm.fit_transform(Y)
# X = scale(X)
# Y = scale(Y)






# from sklearn.decomposition import PCA
# pca = PCA(n_components=2)
# pca.fit(X)
# # PCA(copy=True, n_components=2, whiten=False)
# print('pca_value:',pca.explained_variance_ratio_)


# print(X.shape,Y.shape)
num_data, input_dim = X.shape
print(X.shape)
#print("num_data: "+num_data+"input_dim: "+input_dim)
X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.2, random_state=66)

#num_data = len(X)
print("num_data: "+str(num_data))
print(X.min(),X.max())#0.0,1.0
num_inducing = 50
output_dim = Y_train.shape[1]
print(output_dim)
# output_dim = 100

SE_kernel = gpflow.kernels.SquaredExponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_SE = gpflux.layers.GPLayer(
    SE_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
RQ_kernel = gpflow.kernels.RationalQuadratic()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_RQ = gpflux.layers.GPLayer(
    RQ_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
Matern52_kernel = gpflow.kernels.Matern52()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_Matern52 = gpflux.layers.GPLayer(
    Matern52_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
Matern32_kernel = gpflow.kernels.Matern32()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_Matern32 = gpflux.layers.GPLayer(
    Matern32_kernel, inducing_variable, num_data=num_data, num_latent_gps= output_dim
)
Exp_kernel = gpflow.kernels.Exponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)


likelihood = gpflow.likelihoods.Gaussian(0.01)

# So that Keras can track the likelihood variance, we need to provide the likelihood as part of a "dummy" layer:
likelihood_container = gpflux.layers.TrackableLayer()
likelihood_container.likelihood = likelihood
M = 50
# model = tf.keras.Sequential(
#     [
#         tf.keras.layers.Dense(M, activation="relu"),
#         tf.keras.layers.Dense(M, activation="relu"),
#         tf.keras.layers.Dense(M, activation="relu"),
#         tf.keras.layers.Dense(M, activation="relu"),
#         #
#         tf.keras.layers.Dense(1, activation="linear"),
#         gp_layer_Matern52,
#         gp_layer_Matern52,
#         gp_layer_Matern52,
#         gp_layer_Matern52,
#
#         likelihood_container,  # no-op, for discovering trainable likelihood parameters
#     ]
# )
loss = gpflux.losses.LikelihoodLoss(likelihood)
import Matern_52_kernel
import Matern_32_kernel
import Exp_kernel
import RQ_kernel
import SE_kernel
model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)
model_matern52 = Matern_52_kernel.model_Matern52_kernel
model_RQ = RQ_kernel.model_RQ_kernel
model_Exp = Exp_kernel.model_Exp_kernel
model_matern32 = Matern_32_kernel.model_Matern32_kernel
model_SE = SE_kernel.model_SE_kernel


#estimators3 = [('rf',RandomForestRegressor()),('gb',GradientBoostingRegressor()),
#                   ('ad',AdaBoostRegressor())]
estimators_gp = [
    # ('matern52',model_matern52 ),('matern32',model_matern32),
    #              ('Exp',model_Exp),
                 ('SE1',model_Exp),
    ('SE2', model_Exp),
    ('SE3', model_Exp),
    ('SE4', model_Exp),
    ('SE5', model_Exp),

                 #('gb',GradientBoostingRegressor())
                 ]


final_layer1 = StackingRegressor(
    estimators = [#('dt',DecisionTreeRegressor()),('ad',AdaBoostRegressor()),
                  ('ex',ExtraTreeRegressor()),
        #('hr',HistGradientBoostingRegressor()),
                  #   ('RQ',model_RQ,('Exp'),model_Exp),('SE',model_SE),
                    ('rf',RandomForestRegressor()),
                    #('gb',GradientBoostingRegressor()),
                    #('matern52',model_matern52),
                    #('matern32',model_matern32),
                    ('ad',AdaBoostRegressor()),
                    ('dt',DecisionTreeRegressor())
                  ],
    #estimators = [('dt',DecisionTreeRegressor())],
    #estimators = [('RQ',model_RQ)],
    final_estimator = model_SVR
)
# model = StackingRegressor(estimators=estimators_gp,final_estimator=final_layer1)
model = StackingRegressor(estimators=estimators_gp,final_estimator=final_layer1)
#model = StackingRegressor(estimators=estimators3)
#model = model_matern52

#model.compile(loss=loss, optimizer="adam")
#hist = model.fit(X_train, Y_train, epochs=1000, verbose=0)

model.fit(X_train,Y_train)

y_pred = model.predict(X_test)
y_test = Y_test

# calculate metrics
time12 = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
R2 = r2_score(y_test, y_pred, multioutput='raw_values')  # 拟合优度
R22 = 1 - math.sqrt(1 - R2)
Mse = mean_squared_error(y_test, y_pred)  # 均方差
Mae = mean_absolute_error(y_test, y_pred,
                          sample_weight=None,
                          multioutput='uniform_average')  # 平均绝对误差
Variance = explained_variance_score(y_test, y_pred,
                                    sample_weight=None,
                                    multioutput='uniform_average')  # 可释方差得分
Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差
# if (R2 > 0.9100):
#     print('OK!',R2)
#     np.savetxt('y/y.csv',y_test,delimiter=',')
#     np.savetxt('y/y_pred.csv',y_pred,delimiter=',')
print("当前模型训练结束，时间为： "+time12)
print("R2 :%.4f" % R2)
print("R22 :%.4f" % R22)
print("Mse :%.4f" % Mse)
print("Rmse :%.4f" % math.sqrt(Mse))
print("Mae :%.4f" % Mae)
print("Variance :%.4f" % Variance)
print("Meae :%.4f" % Meae)
# print("total_time :%.4f" % total_time)
# if (R2 > 0.91):
#     print('OK!',R2)
#     np.savetxt('y/y.csv',y_test,delimiter=',')
#     np.savetxt('y/y_pred.csv',y_pred,delimiter=',')
# Mylog = open('Record3.29-五层神经网络节点100-五层Matern52.txt', mode ='a', encoding='utf-8')
# print("R2 :%.4f" % R2,file=Mylog)
# print("R22 :%.4f" % R22,file=Mylog)
# print("Mse :%.4f" % Mse,file=Mylog)
# print("Rmse :%.4f" % math.sqrt(Mse),file=Mylog)
# print("Mae :%.4f" % Mae,file=Mylog)
# print("Variance :%.4f" % Variance,file=Mylog)
# print("Meae :%.4f" % Meae,file=Mylog)
# Mylog.close()

# plt.plot(hist.history["loss"])


def plot(model, X, Y, ax=None):
    if ax is None:
        fig, ax = plt.subplots()

    x_margin = 1.0
    N_test = 6
    X_test = np.linspace(X.min() - x_margin, X.max() + x_margin, N_test).reshape(-1, 1)

    print(X_test.shape)
    f_distribution = model(X_test)

    mean = f_distribution.mean().numpy().squeeze()
    var = f_distribution.variance().numpy().squeeze()
    X_test = X_test.squeeze()
    lower = mean - 2 * np.sqrt(var)
    upper = mean + 2 * np.sqrt(var)

    ax.set_ylim(Y.min() - 0.5, Y.max() + 0.5)
    ax.plot(X, Y, "kx", alpha=0.5)
    ax.plot(X_test, mean, "C1")

    ax.fill_between(X_test, lower, upper, color="C1", alpha=0.3)


# plot(model, X, Y)