# 导入所需的库
import math
import time

import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, median_absolute_error
from sklearn.model_selection import train_test_split
from tensorflow import keras

cpu = tf.config.list_physical_devices("CPU")
tf.config.set_visible_devices(cpu)
tf.keras.backend.set_floatx("float64")
# 创建一个模拟的回归数据集
dataframe = pd.read_csv('E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\motor_100W_pm.csv',header=None)
#dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\\6000.csv',header=None)

dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)
df2 = df2.values


X = df2[:,0:column-1]
Y = df2[:,column-1:column]

# with open('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\jiediansunhao.csv', 'r') as f:
#     reader = csv.reader(f)
#     data = []
#     for i in reader:
#         data += [[float(j) for j in i]]
# t = np.array(data)
# data = np.swapaxes(t, 0, 1)
# X = np.swapaxes(data[:6], 0, 1)
# y = np.swapaxes(data[6:], 0, 1)
# # with open('data/2000.csv', 'r') as f:
# # 	reader = csv.reader(f)
# # 	data = []
# # 	for i in reader:
# # 		data += [[float(j) for j in i]]
# # t = np.array(data)
# # data = np.swapaxes(t, 0, 1)
# # X = np.swapaxes(data[:11], 0, 1)
# # y = np.swapaxes(data[11:], 0, 1)
# y = y.ravel()

from sklearn.preprocessing import scale, MinMaxScaler,StandardScaler
# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)
# 定义深度神经网络模型
X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.2, random_state=66)
model = keras.Sequential([
    #layers.Input(shape=(1,)),  # 输入层
#keras.layers.Dense(1),
    keras.layers.Dense(64, activation='relu'),  # 隐藏层1，64个神经元
    keras.layers.Dense(64, activation='relu'),  # 隐藏层2，64个神经元
    keras.layers.Dense(1)  # 输出层，回归问题只需要一个输出
])

# 编译模型
model.compile(optimizer='adam', loss='mean_squared_error')

# 训练模型
model.fit(X_train, Y_train, epochs=100, verbose=0)

# 使用模型进行预测

y_pred = model.predict(X_test)
# calculate metrics
time12 = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
R2 = r2_score(Y_test, y_pred, multioutput='raw_values')  # 拟合优度
R22 = 1 - math.sqrt(1 - R2)
Mse = mean_squared_error(Y_test, y_pred)  # 均方差
Mae = mean_absolute_error(Y_test, y_pred,
                          sample_weight=None,
                          multioutput='uniform_average')  # 平均绝对误差

Meae = median_absolute_error(Y_test, y_pred)  # 中值绝对误差
# if (R2 > 0.9100):
#     print('OK!',R2)
#     np.savetxt('y/y.csv',y_test,delimiter=',')
#     np.savetxt('y/y_pred.csv',y_pred,delimiter=',')
print("当前模型训练结束，时间为： "+time12)
print("R2 :%.4f" % R2)
print("R22 :%.4f" % R22)
print("Mse :%.4f" % Mse)
print("Rmse :%.4f" % math.sqrt(Mse))
print("Mae :%.4f" % Mae)
print("Meae :%.4f" % Meae)