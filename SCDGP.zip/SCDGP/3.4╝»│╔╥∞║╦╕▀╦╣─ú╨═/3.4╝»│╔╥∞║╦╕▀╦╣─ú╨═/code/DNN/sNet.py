import math
import time

import numpy as np
import pandas as pd
from m5py import M5Prime
from sklearn import svm
from sklearn.ensemble import StackingRegressor, AdaBoostRegressor, RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, explained_variance_score, \
    median_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor

dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\dianji_cjl.CSV',header=None)


dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)
df2 = df2.values


X = df2[:,0:column-1]
Y = df2[:,column-1:column]
from sklearn.preprocessing import scale, MinMaxScaler,RobustScaler,StandardScaler
# X = scale(X)
# Y = scale(Y)
# scaler = StandardScaler()
# X = scaler.fit_transform(X)
# Y = scaler.fit_transform(Y)
# mm = MinMaxScaler()
# X = mm.fit_transform(X)
# Y = mm.fit_transform(Y)
X = scale(X)
Y = scale(Y)
X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.2, random_state=66)
model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)
regr_1 = M5Prime(use_smoothing=False, use_pruning=False)
estimators_gp = [
                 ('rf',RandomForestRegressor()),
                 ('gb',GradientBoostingRegressor())
                 ]


final_layer1 = StackingRegressor(
    estimators = [#('dt',DecisionTreeRegressor()),('ad',AdaBoostRegressor()),
                  #('ex',ExtraTreeRegressor()),('hr',HistGradientBoostingRegressor()),
                  #   ('RQ',model_RQ,('Exp'),model_Exp),('SE',model_SE),
                    #('rf',RandomForestRegressor()),
                    #('gb',GradientBoostingRegressor()),
                    #('matern52',model_matern52),
                    #('matern32',model_matern32),

        ('m5',regr_1),
                    ('dt',DecisionTreeRegressor())
                  ],
    #estimators = [('dt',DecisionTreeRegressor())],
    #estimators = [('RQ',model_RQ)],

)
# model = StackingRegressor(estimators=estimators_gp,final_estimator=final_layer1)
model = StackingRegressor(estimators=estimators_gp,final_estimator=final_layer1)
model.fit(X_train,Y_train)

y_pred = model.predict(X_test)
#regr_1.fit(X_train,Y_train)
#y_pred = regr_1.predict(X_test)
y_test = Y_test

# calculate metrics
time12 = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
R2 = r2_score(y_test, y_pred, multioutput='raw_values')  # 拟合优度
R22 = 1 - math.sqrt(1 - R2)
Mse = mean_squared_error(y_test, y_pred)  # 均方差
Mae = mean_absolute_error(y_test, y_pred,
                          sample_weight=None,
                          multioutput='uniform_average')  # 平均绝对误差
Variance = explained_variance_score(y_test, y_pred,
                                    sample_weight=None,
                                    multioutput='uniform_average')  # 可释方差得分
Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差
# if (R2 > 0.9100):
#     print('OK!',R2)
#     np.savetxt('y/y.csv',y_test,delimiter=',')
#     np.savetxt('y/y_pred.csv',y_pred,delimiter=',')
print("当前模型训练结束，时间为： "+time12)
print("R2 :%.4f" % R2)
print("R22 :%.4f" % R22)
print("Mse :%.4f" % Mse)
print("Rmse :%.4f" % math.sqrt(Mse))
print("Mae :%.4f" % Mae)
print("Variance :%.4f" % Variance)
print("Meae :%.4f" % Meae)
