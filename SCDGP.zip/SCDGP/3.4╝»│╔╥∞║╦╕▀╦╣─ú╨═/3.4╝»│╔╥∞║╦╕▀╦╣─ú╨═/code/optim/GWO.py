from swarmlib import GWOProblem, FUNCTIONS

problem = GWOProblem(wolves=10, function=FUNCTIONS['michalewicz'])
best_wolf = problem.solve()
print(best_wolf)
problem.replay()