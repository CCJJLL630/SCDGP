
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, DotProduct, ExpSineSquared
from sklearn.metrics import mean_squared_error
# from mlxtend.regressor import StackingRegressor
from sklearn.ensemble import StackingRegressor,GradientBoostingRegressor,RandomForestRegressor,AdaBoostRegressor
from sklearn.tree import ExtraTreeRegressor
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold
import csv
import math
from sklearn import svm
import numpy as np
import xlwt
import openpyxl
# with open('data/jieguo700.csv', 'r') as f:
# 	reader = csv.reader(f)
# 	data = []
# 	for i in reader:
# 		data += [[float(j) for j in i]]
# t = np.array(data)
with open('D:\CjlNoFile\组会文件\深度高斯过程/3.4集成异核高斯模型/3.4集成异核高斯模型\data\jieguo700.csv', 'r') as f:
    reader = csv.reader(f)
    data = []
    for i in reader:
        data += [[float(j) for j in i]]
t = np.array(data)
#print(t.shape)
data = np.swapaxes(t, 0, 1)

X = np.swapaxes(data[:4], 0, 1)
#print(data[:13].shape)
y = np.swapaxes(data[4:], 0, 1)
#print(y)
kfold = KFold(n_splits=5)
#Rosenbrock function

def f(x):
    Y_Pred = []
    Y_Test = []


    model_SVR = svm.SVR(kernel='linear', gamma=x[0], C=x[1])

    kernel1 = RationalQuadratic()
    kernel2 = Matern()
    kernel3 = RBF()
    kernel4 = RationalQuadratic() + Matern()
    kernel5 = Matern() + RBF()
    # kernel6 = RBF()+RationalQuadratic()
    gp1 = GaussianProcessRegressor(kernel=kernel1, alpha=x[2])
    gp2 = GaussianProcessRegressor(kernel=kernel2, alpha=x[3])
    gp3 = GaussianProcessRegressor(kernel=kernel3, alpha=x[4])
    gp4 = GaussianProcessRegressor(kernel=kernel4)
    gp5 = GaussianProcessRegressor(kernel=kernel5)
    # gp6 = GaussianProcessRegressor(kernel=kernel6)

    estimators3 = [('rf', RandomForestRegressor(n_estimators=20)), ('gb', GradientBoostingRegressor(n_estimators=50)),
                   ('ad', AdaBoostRegressor(n_estimators=20)), ('ex', ExtraTreeRegressor())]

    final_layer = StackingRegressor(
        estimators=[('gp1', gp1), ('gp2', gp2), ('gp3', gp3)], final_estimator=model_SVR
    )
    _3reg = StackingRegressor(estimators=estimators3, final_estimator=final_layer)


    for train, test in kfold.split(X):
        X_train = np.array(X)[train]
        y_train = np.array(y)[train]

        #print(X_train,y_train)
        X_test = np.array(X)[test]
        y_test = np.array(y)[test]
        # print(X_test)


        _3reg.fit(X_train, y_train)
        Y_predicted = _3reg.predict(X_test)

        Mse = mean_squared_error(y_test, Y_predicted)
        #print(Mse)
        Y_Pred.append(Y_predicted.tolist())
        Y_Test.append(y_test.tolist())

    y_pred = sum(Y_Pred, [])
    y_test = sum(Y_Test, [])
    y_pred = np.array(y_pred)
    y_test = np.array(y_test)
    y_pred = y_pred.reshape(-1, 1)
    y_test = y_test.reshape(-1, 1)
    r2 = r2_score(y_test, y_pred, multioutput='raw_values')
    Mse = mean_squared_error(y_test, y_pred)
    rmse = math.sqrt(Mse)
    print('parameters: ', x[0],x[1],x[2],x[3],x[4])
    print('mse: ',Mse)
    print('r2: ',r2[0])
    print('rmse: ',rmse)
    # x_list = []
    # x_list.append( x[0])
    # x_list.append(x[1])
    # x_list.append(x[2])
    # x_list.append(x[3])
    # x_list.append(x[4])
    # map[r2] = x_list
    wb = openpyxl.load_workbook("D:\CjlNoFile\组会文件\深度高斯过程/3.4集成异核高斯模型/3.4集成异核高斯模型\data/result.xlsx")
    sheet = wb.active
    i = 1
    while sheet.cell(row=i,column=1).value != None:
        i += 1
    sheet.cell(row=i,column=1).value = r2[0]
    sheet.cell(row=i,column=2).value = Mse
    sheet.cell(row=i,column=3).value = rmse
    sheet.cell(row=i,column=4).value = x[0]
    sheet.cell(row=i,column=5).value = x[1]
    sheet.cell(row=i,column=6).value = x[2]
    sheet.cell(row=i,column=7).value = x[3]
    sheet.cell(row=i,column=8).value = x[4]
    wb.save("D:\CjlNoFile\组会文件\深度高斯过程/3.4集成异核高斯模型/3.4集成异核高斯模型\data/result.xlsx")


    return Mse


from sko.AFSA import AFSA

afsa = AFSA(f, n_dim=5, size_pop=50, max_iter=300,
            max_try_num=100, step=0.5, visual=0.3,
            q=0.98, delta=0.5)

best_x, best_y = afsa.run()
print(best_x)
print("===========================================")
print(best_y)