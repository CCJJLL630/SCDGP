from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.rnsga3 import RNSGA3
from pymoo.optimize import minimize
from pymoo.problems import get_problem
from pymoo.visualization.scatter import Scatter




import csv
import math

import numpy as np
from sklearn import svm
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.model_selection import KFold

with open('D:\CjlNoFile\组会文件\深度高斯过程/3.4集成异核高斯模型/3.4集成异核高斯模型\data\housing3.csv', 'r') as f:
    reader = csv.reader(f)
    data = []
    for i in reader:
        data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)
X = np.swapaxes(data[:13], 0, 1)
y = np.swapaxes(data[13:], 0, 1)
kfold = KFold(n_splits=5)
#Rosenbrock function
def f(x):

    R2_l = []
    Mse_l = []
    Rmse_l = []
    Y_Pred = []
    Y_Test = []
    for train, test in kfold.split(X):
        X_train = np.array(X)[train]
        y_train = np.array(y)[train]
        # print(X_train,y_train)
        X_test = np.array(X)[test]
        y_test = np.array(y)[test]
        # print(X_test)
        # kernel1 = RationalQuadratic()
        # kernel2 = Matern()
        # kernel3 = RBF()
        # kernel4 = RationalQuadratic() + Matern()
        # kernel5 = Matern() + RBF()
        # # kernel6 = RBF()+RationalQuadratic()
        # gp1 = GaussianProcessRegressor(kernel=kernel1, alpha=x[0])
        # gp2 = GaussianProcessRegressor(kernel=kernel2,alpha=x[1])
        # gp3 = GaussianProcessRegressor(kernel=kernel3, alpha=x[2])
        # gp4 = GaussianProcessRegressor(kernel=kernel4, alpha=x[3])
        # gp5 = GaussianProcessRegressor(kernel=kernel5, alpha=x[4])
        # # gp6 = GaussianProcessRegressor(kernel=kernel6)
        # regressors = [gp4, gp1, gp3, gp5]
        model_SVR = svm.SVR(kernel='linear', gamma=x[0], C=x[1])
        print(x[0],x[1])
        # reg = StackingRegressor(regressors=regressors, meta_regressor=gp2)
        model_SVR.fit(X_train, y_train)
        Y_predicted = model_SVR.predict(X_test)
        R2 = r2_score(y_test, Y_predicted)
        Mse = mean_squared_error(y_test, Y_predicted)

        Rmse = math.sqrt(Mse)
        R2_l.append(R2)
        Mse_l.append(Mse)
        Rmse_l.append(Rmse)
        Y_Pred.append(Y_predicted.tolist())
        Y_Test.append(y_test.tolist())
    y_pred = sum(Y_Pred, [])
    y_test = sum(Y_Test, [])
    y_pred = np.array(y_pred)
    y_test = np.array(y_test)
    y_pred = y_pred.reshape(-1, 1)
    y_test = y_test.reshape(-1, 1)
    R2 = r2_score(y_test, y_pred, multioutput='raw_values')
    Mse = mean_squared_error(y_test, y_pred)
    print(Mse)
    return Mse









problem = get_problem("zdt1")
algorithm = RNSGA3(pop_size=100,ref_points=100,pop_per_ref_point=20)

res = minimize(problem,
               algorithm,
               ('n_gen', 200),
               seed=1,
               verbose=True)

plot = Scatter()
plot.add(problem.pareto_front(), plot_type="line", color="black", alpha=0.7)
plot.add(res.F, color="red")
plot.show()