import time

import gpflow
import gpflux
import pandas as pd
import xgboost
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, DotProduct, ExpSineSquared
from sklearn.metrics import mean_squared_error, mean_absolute_error, explained_variance_score, median_absolute_error
# from mlxtend.regressor import StackingRegressor
from sklearn.ensemble import StackingRegressor,GradientBoostingRegressor,RandomForestRegressor,AdaBoostRegressor
from sklearn.tree import ExtraTreeRegressor, DecisionTreeRegressor
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold
import csv
import math
from sklearn import svm
import numpy as np

import openpyxl
from xgboost import XGBRegressor
import lightgbm as lgb
import tensorflow as tf
cpu = tf.config.list_physical_devices("CPU")
tf.config.set_visible_devices(cpu)
dataframe = pd.read_csv('E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\dianji_cjl.CSV',header=None)

dataset = dataframe.values
row, column = dataset.shape
print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)


df2 = df2.values


X = df2[:,0:column-1]
Y = df2[:,column-1:column]
from dgp_model.metric_caculate import get_R2_score, Mean_squared_error
from sklearn.preprocessing import scale, MinMaxScaler,RobustScaler,StandardScaler
# X = scale(X)
# Y = scale(Y)
# scaler = StandardScaler()
# X = scaler.fit_transform(X)
# Y = scaler.fit_transform(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)
num_data, input_dim = X.shape
print(X.shape)
#print("num_data: "+num_data+"input_dim: "+input_dim)
X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.2, random_state=66)

#num_data = len(X)
print("num_data: "+str(num_data))
print(X.min(),X.max())#0.0,1.0
num_inducing = 50
output_dim = Y_train.shape[1]
print(output_dim)
# output_dim = 100


import Matern_52_kernel
import Matern_32_kernel
import Exp_kernel
import RQ_kernel
import SE_kernel
from sklearn.neighbors import KNeighborsRegressor
model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)
model_knn = KNeighborsRegressor()
model_matern52 = Matern_52_kernel.model_Matern52_kernel
model_RQ = RQ_kernel.model_RQ_kernel
model_Exp = Exp_kernel.model_Exp_kernel
model_matern32 = Matern_32_kernel.model_Matern32_kernel
model_SE = SE_kernel.model_SE_kernel



def f(x):
    estimators = [
        ('matern52', model_matern52),
        ('matern32', model_matern32),
        ('Exp', model_Exp),
        ('SE', model_SE),
        ('RQ', model_RQ),
        # ('rf', RandomForestRegressor()),
        # ('gb',GradientBoostingRegressor())
    ]
    SE_kernel = gpflow.kernels.SquaredExponential()
    inducing_variable = gpflow.inducing_variables.InducingPoints(
        np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
    )
    gp_layer_SE = gpflux.layers.GPLayer(
        SE_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
    )
    RQ_kernel = gpflow.kernels.RationalQuadratic()
    inducing_variable = gpflow.inducing_variables.InducingPoints(
        np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
    )
    gp_layer_RQ = gpflux.layers.GPLayer(
        RQ_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
    )
    Matern52_kernel = gpflow.kernels.Matern52()
    inducing_variable = gpflow.inducing_variables.InducingPoints(
        np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
    )
    gp_layer_Matern52 = gpflux.layers.GPLayer(
        Matern52_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
    )
    Matern32_kernel = gpflow.kernels.Matern32()
    inducing_variable = gpflow.inducing_variables.InducingPoints(
        np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
    )
    estimators.append(('rf', RandomForestRegressor()))
    gp_layer_Matern32 = gpflux.layers.GPLayer(
        Matern32_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
    )
    Exp_kernel = gpflow.kernels.Exponential()
    inducing_variable = gpflow.inducing_variables.InducingPoints(
        np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
    )
    estimators3 = [('rf', RandomForestRegressor()), ('gb', GradientBoostingRegressor()),
                   ('ad', AdaBoostRegressor()),('DC',DecisionTreeRegressor())]
    estimators_gp = [
       ('matern52', model_matern52),
       ('matern32', model_matern32),
                     ('Exp', model_Exp),
                     ('SE', model_SE),
                     ('RQ',model_RQ),
                     #('rf', RandomForestRegressor()),
                     # ('gb',GradientBoostingRegressor())
                     ]

    estimators_gp = estimators_gp.append(('rf', RandomForestRegressor()))
    final_layer1 = StackingRegressor(
        estimators=[  # ('dt',DecisionTreeRegressor()),
            #('ad',AdaBoostRegressor()),
             ('ex',ExtraTreeRegressor()),
            ('gbm',lgb.LGBMRegressor()),
            #('hr',HistGradientBoostingRegressor()),
            #   ('RQ',model_RQ,('Exp'),model_Exp),('SE',model_SE),
           # ('rf',RandomForestRegressor()),
            ('gb',GradientBoostingRegressor(alpha=x[0])),
            # ('matern52',model_matern52),
            # ('matern32',model_matern32),
            ('ad', AdaBoostRegressor()),
           # ('dt',DecisionTreeRegressor()),
            #('xg',xgboost.XGBRegressor())
        ],
        # estimators = [('dt',DecisionTreeRegressor())],
        # estimators = [('RQ',model_RQ)],
        final_estimator=model_SVR
    )
    model = StackingRegressor(estimators=estimators, final_estimator=final_layer1)
    model.fit(X_train, Y_train)

    y_pred = model.predict(X_test)
    y_test = Y_test

    # calculate metrics

    R2 = get_R2_score(y_test, y_pred)
    R22 = 1 - math.sqrt(1 - R2)
    Mse = Mean_squared_error(y_test, y_pred)  # 均方差
    Mae = mean_absolute_error(y_test, y_pred,
                              sample_weight=None,
                              multioutput='uniform_average')  # 平均绝对误差
    Variance = explained_variance_score(y_test, y_pred,
                                        sample_weight=None,
                                        multioutput='uniform_average')  # 可释方差得分
    Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差
    # if (R2 > 0.9100):
    #     print('OK!',R2)
    #     np.savetxt('y/y.csv',y_test,delimiter=',')
    #     np.savetxt('y/y_pred.csv',y_pred,delimiter=',')
    time12 = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("当前模型训练完成，时间为：" + time12)
    print("R2 :%.4f" % R2)
    print("R22 :%.4f" % R22)
    print("Mse :%.4f" % Mse)
    print("Rmse :%.4f" % math.sqrt(Mse))
    print("Mae :%.4f" % Mae)
    print("Variance :%.4f" % Variance)
    print("Meae :%.4f" % Meae)
    wb = openpyxl.load_workbook("E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\code\optim\\result\CSAresult-11.xlsx")
    sheet = wb.active
    i = 1
    while sheet.cell(row=i,column=1).value != None:
        i += 1
    sheet.cell(row=i,column=1).value = x[0]
    sheet.cell(row=i, column=2).value = x[1]
    sheet.cell(row=i,column=3).value = str(R2)
    sheet.cell(row=i, column=4).value = str(R22)
    sheet.cell(row=i, column=5).value = Mse
    sheet.cell(row=i, column=6).value = str(math.sqrt(Mse))
    sheet.cell(row=i, column=7).value = str(Mae)
    sheet.cell(row=i, column=8).value = str(Meae)
    sheet.cell(row=i, column=9).value = time12

    wb.save("E:\CjlFile\组会文件\深度高斯过程\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\code\optim\\result\CSAresult-11.xlsx")


    return Mse
#Swarm-intelligence-optimization-algorithm
import swarm_algorithm
import swarmlib
import sko
sbo = swarm_algorithm.SBO(func=f,n_dim=10,lb=0.000001,ub=1,max_iter=10)
#ssa = swarm_algorithm.SSA2017(func=f,n_dim=10,lb=0.000001,ub=1,max_iter=10)
# csa = swarm_algorithm.CSA(func=f,n_dim=10,lb=0.000001,ub=1,max_iter=10)
# sca = swarm_algorithm.SCA(func=f,n_dim=10,lb=0.000001,ub=1,max_iter=10)
# pso = swarm_algorithm.PSO(func=f,n_dim=10,lb=0.000001,ub=0.99999999999,max_iter=10)
# ssa = swarm_algorithm.SSA2020(func=f,n_dim=30,lb=0.000001,ub=1)
# de = sko.DE.DE(f,n_dim=10,lb=0.000001,ub=0.99999999999,max_iter=10)
#ga = sko.GA.GA(func=f,n_dim=10,lb=0.000001,ub=0.99999999999,max_iter=10)
#fa  = swarm_algorithm.FA(func=f,n_dim=10,lb=0.000001,ub=0.99999999999,max_iter=10)
x,y = sbo.run()
#x,y = de.run()

print(x)