from Stacking_Ensembles import stacking_classifier
from sklearn.gaussian_process.kernels import RationalQuadratic,RBF,Matern,ExpSineSquared
from Stacking_Ensembles.stacking_regressor import RandomForestRegressor,KFolds_Regressor_Training_Wrapper,\
    StackingRegressor,AdaBoostRegressor,GradientBoostingRegressor,RQGaussianProcessRegressor,MGaussianProcessRegressor,\
    RBFGaussianProcessRegressor
from sklearn.metrics import mean_squared_error,r2_score
from lightgbm import LGBMRegressor
import numpy as np
import csv,math
from sklearn.model_selection import train_test_split, KFold

with open('data/jieguo700.csv', 'r') as f:
    reader = csv.reader(f)
    data = []
    for i in reader:
        data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)
X = np.swapaxes(data[:4], 0, 1)
y = np.swapaxes(data[4:], 0, 1)
kfold = KFold(n_splits=5)

R2_l = []
Mse_l = []
Rmse_l = []
Y_Pred = []
Y_Test = []
for train, test in kfold.split(X):
    X_train = np.array(X)[train]
    y_train = np.array(y)[train]
    # print(X_train,y_train)
    X_test = np.array(X)[test]
    y_test = np.array(y)[test]
    # regressor = RandomForestRegressor()
    # regressor = KFolds_Regressor_Training_Wrapper(regressor, k_fold=5)  # 这里封装一下即可，默认k_fold=5
    regressor = StackingRegressor(
        base_regressors=[
            AdaBoostRegressor(),
            GradientBoostingRegressor(),
            RandomForestRegressor()
        ],
        meta_regressor=RandomForestRegressor(),
        force_cv=False
    )
    regressor.build_model()
    lgb = LGBMRegressor()
    lgb.fit(X_train, y_train)
    p_test = lgb.predict(X_test)
    R2 = r2_score(y_test, p_test)
    Mse = mean_squared_error(y_test, p_test)
    print(Mse)
    Rmse = math.sqrt(Mse)
    R2_l.append(R2)
    Mse_l.append(Mse)
    Rmse_l.append(Rmse)


print('R2:',np.mean(R2_l))
print('Mse:',np.mean(Mse_l))
print('Rmse:',np.mean(Rmse_l))
