import math

import numpy as np
import scikeras
from keras.losses import mean_squared_error
from scikeras.wrappers import KerasRegressor
from sklearn.metrics import r2_score
from tensorflow import keras
from sklearn.datasets import make_regression
from sklearn.ensemble import VotingRegressor
from sklearn.linear_model import LinearRegression

class MLPRegressor(KerasRegressor):

    def __init__(
        self,
        hidden_layer_sizes=(100, ),
        optimizer="adam",
        optimizer__learning_rate=0.001,
        epochs=10,
        verbose=0,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.hidden_layer_sizes = hidden_layer_sizes
        self.optimizer = optimizer
        self.epochs = epochs
        self.verbose = verbose

    def _keras_build_fn(self, compile_kwargs):
        model = keras.Sequential()
        inp = keras.layers.Input(shape=(self.n_features_in_))
        model.add(inp)
        for hidden_layer_size in self.hidden_layer_sizes:
            layer = keras.layers.Dense(hidden_layer_size, activation="relu")
            model.add(layer)
        out = keras.layers.Dense(1)
        model.add(out)
        model.compile(loss="mse", optimizer=compile_kwargs["optimizer"])
        return model

# simple linear regression
r1 = LinearRegression()
# keras model wrapper
r2= MLPRegressor(epochs=20)


# y = np.arange(100)
# X = (y/2).reshape(-1, 1)
#
#
# #defining votting classifier
# vr = VotingRegressor([('lr', r1), ('MLPReg', r2)])
#
# vr.fit(X,y)
# Y_predicted = vr.predict(X)
#
#
# R2 = r2_score(y, Y_predicted)
# Mse = mean_squared_error(y, Y_predicted)
# Rmse = math.sqrt(Mse)
#
# print("R23 :%.4f" % R2)
# print("Mse :%.4f" % Mse)
# print("Rmse :%.4f" % math.sqrt(Mse))