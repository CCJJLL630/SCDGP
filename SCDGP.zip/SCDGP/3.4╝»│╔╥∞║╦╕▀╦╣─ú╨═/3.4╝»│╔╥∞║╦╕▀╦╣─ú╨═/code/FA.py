'''
@uthor : Amit Nandi
Date : 10/11/2016

Firefly Alogrithm 
'''

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, DotProduct, ExpSineSquared
from sklearn.metrics import mean_squared_error
# from mlxtend.regressor import StackingRegressor
from sklearn.ensemble import StackingRegressor,GradientBoostingRegressor,RandomForestRegressor,AdaBoostRegressor
from sklearn.tree import ExtraTreeRegressor
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold
import csv
import math
from sklearn import svm
import numpy as np
from xgboost import XGBRegressor
import lightgbm as lgb
import catboost as cb
# with open('data/jieguo700.csv', 'r') as f:
# 	reader = csv.reader(f)
# 	data = []
# 	for i in reader:
# 		data += [[float(j) for j in i]]
# t = np.array(data)
with open('D:\CjlNoFile\组会文件\深度高斯过程/3.4集成异核高斯模型/3.4集成异核高斯模型\data\jieguo700.csv', 'r') as f:
	reader = csv.reader(f)
	data = []
	for i in reader:
		data += [[float(j) for j in i]]
t = np.array(data)
print(t.shape)
data = np.swapaxes(t, 0, 1)

X = np.swapaxes(data[:13], 0, 1)
print(data[:13].shape)
y = np.swapaxes(data[13:], 0, 1)
print(y)
kfold = KFold(n_splits=5)
#Rosenbrock function
def f(x):
	Y_Pred = []
	Y_Test = []
	model_SVR = svm.SVR(kernel='linear', gamma=x[0], C=x[1])
	kernel1 = RationalQuadratic()
	kernel2 = Matern()
	kernel3 = RBF()
	kernel4 = RationalQuadratic() + Matern()
	kernel5 = Matern() + RBF()
	# kernel6 = RBF()+RationalQuadratic()
	gp1 = GaussianProcessRegressor(kernel=kernel1, alpha=x[2])
	gp2 = GaussianProcessRegressor(kernel=kernel2, alpha=x[3])
	gp3 = GaussianProcessRegressor(kernel=kernel3, alpha=x[4])
	gp4 = GaussianProcessRegressor(kernel=kernel4)
	gp5 = GaussianProcessRegressor(kernel=kernel5)
	# gp6 = GaussianProcessRegressor(kernel=kernel6)

	# estimators3 = [('rf', RandomForestRegressor(n_estimators=20)), ('gb', GradientBoostingRegressor(n_estimators=50)),
	# 			   ('ad', AdaBoostRegressor(n_estimators=20)), ('ex', ExtraTreeRegressor())]
	estimators3 = [('rf', XGBRegressor()), ('gb', lgb.LGBMRegressor()),
				   ('ad', cb.CatBoostRegressor()), ('ex', cb.CatBoostRegressor())]

	final_layer = StackingRegressor(
		estimators=[('gp1', gp1), ('gp2', gp2), ('gp3', gp3)], final_estimator=model_SVR
	)
	_3reg = StackingRegressor(estimators=estimators3, final_estimator=final_layer)


	for train, test in kfold.split(X):
		X_train = np.array(X)[train]
		y_train = np.array(y)[train]

		print(X_train,y_train)
		X_test = np.array(X)[test]
		y_test = np.array(y)[test]
		# print(X_test)


		_3reg.fit(X_train, y_train)
		Y_predicted = _3reg.predict(X_test)

		Mse = mean_squared_error(y_test, Y_predicted)
		print(Mse)
		Y_Pred.append(Y_predicted.tolist())
		Y_Test.append(y_test.tolist())

	y_pred = sum(Y_Pred, [])
	y_test = sum(Y_Test, [])
	y_pred = np.array(y_pred)
	y_test = np.array(y_test)
	y_pred = y_pred.reshape(-1, 1)
	y_test = y_test.reshape(-1, 1)
	R2 = r2_score(y_test, y_pred, multioutput='raw_values')
	Mse = mean_squared_error(y_test, y_pred)
	rmse = math.sqrt(Mse)
	print('parameters: ', x[0],x[1],x[2],x[3],x[4])
	print('mse: ',Mse)
	print('r2: ',R2)
	print('rmse: ',rmse)
	return Mse




#Function to compute Intensity
def intensity(trialSolution,f):
	import numpy as n
	I = n.empty(trialSolution.shape[0])
	for i in range(trialSolution.shape[0]):
		I[i] = f(trialSolution[i])
	return I

#Function to compute Euclidean distance
def dist(x,y):
	import numpy as n
	tmp = 0
	for i in range(x.shape[0]):
		tmp = tmp + (x[i]-y[i])**2
	return n.sqrt(tmp)

#Firefly algorithm function
def FA(f,minRange,maxRange,maxItr=5,nFireflies=4,gamma=1,beta0=2,alpha=0.2,delta=1e-3,m=2):
	import numpy as n
	trialSolution = n.empty([nFireflies,len(minRange)])

	for i in range(nFireflies):
		for j in range(len(minRange)):
			trialSolution[i][j] = n.random.uniform(minRange[j],maxRange[j])

	itr = 0
	I = intensity(trialSolution,f)
	while itr!=maxItr:
		for i in range(nFireflies):
			for j in range(i+1):
				if I[j]<I[i]:
					r = dist(trialSolution[i],trialSolution[j])
					beta = beta0*n.exp(-gamma*r**m)
					e = delta*n.random.uniform(-1,1,size=len(minRange))
					tmp = beta*n.dot(n.random.uniform(-1,1,size=(len(minRange),len(minRange))),trialSolution[i]-trialSolution[j])

					trialSolution[i] = trialSolution[i] + alpha*e + tmp
					I = intensity(trialSolution,f)
					print(I)
		itr = itr + 1

	bstValue = min(I)
	bstSol = trialSolution[n.where(I==min(I))]
	print(list((bstValue,bstSol)))
	return list((bstValue,bstSol))

#Main

# minRange = [1e-10, 1e-10,1e-10,1e-10,1e-10]
# maxRange = [1e-5, 1e-5,1e-5,1e-5,1e-5]
maxRange = [1,1,1,1,1]
minRange = [0.001,0.001,1e-6,1e-6,1e-6]
a = FA(f, minRange, maxRange)





