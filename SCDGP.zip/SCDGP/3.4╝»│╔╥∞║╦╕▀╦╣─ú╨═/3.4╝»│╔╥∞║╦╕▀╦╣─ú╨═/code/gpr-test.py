# -*- coding: utf-8 -*-
"""
Created on Tue Jul 10 14:00:24 2018

@author: gh
"""

from sklearn.model_selection import RandomizedSearchCV
# from math import sqrt
import matplotlib.pyplot as plt
import numpy as np

np.random.seed(42)
import csv
# import scipy as sp
from sklearn.metrics import explained_variance_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import median_absolute_error
from sklearn.metrics import r2_score
from sklearn import preprocessing
import math
from scipy import stats
from sklearn.model_selection import cross_val_predict
with open('data/carbon/hard/hard-y1.csv', 'r') as f:
    reader = csv.reader(f)
    data = []
    for i in reader:
        data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)

X = np.swapaxes(data[:5], 0, 1)
y = np.swapaxes(data[5:], 0, 1)
from scipy.stats import zscore
X = zscore(X)
y = zscore(y)

'''
def rmse(y_test, y):
    return sp.sqrt(sp.mean((y_test - y) ** 2))

def R2(y_test, y_true):
    return 1 - ((y_test - y_true)**2).sum() / ((y_true - y_true.mean())**2).sum()


def R22(y_test, y_true):
    y_mean = np.array(y_true)
    y_mean[:] = y_mean.mean()
    return 1 - rmse(y_test, y_true) / rmse(y_mean, y_true)
'''

from sklearn.gaussian_process import GaussianProcessRegressor

from sklearn.gaussian_process.kernels import (RBF, Matern, RationalQuadratic)

kernels = [RBF(),
           RationalQuadratic(),
           Matern(),
           RationalQuadratic() + Matern(),
           Matern() + RBF()

           ]

for fig_index, kernel in enumerate(kernels):
    # Specify Gaussian Process
    gp = GaussianProcessRegressor(kernel=kernel)  # 此处修改
    Y_pred = cross_val_predict(gp, X, y, cv=5)
    print(kernel)
    R2 = r2_score(y, Y_pred, multioutput='raw_values')  # 拟合优度
    R22 = 1 - math.sqrt(1 - R2)
    Mse = mean_squared_error(y, Y_pred)  # 均方差
    Mae = mean_absolute_error(y, Y_pred,
                              sample_weight=None,
                              multioutput='uniform_average')  # 平均绝对误差
    Variance = explained_variance_score(y, Y_pred,
                                        sample_weight=None,
                                        multioutput='uniform_average')  # 可释方差得分
    Meae = median_absolute_error(y, Y_pred)  # 中值绝对误差
    print("R2 :%.4f" % R2)
    print("R22 :%.4f" % R22)
    print("Mse :%.4f" % Mse)
    print("Rmse :%.4f" % math.sqrt(Mse))
    # print("Mae :%.4f" % Mae)
    # print("Variance :%.4f" % Variance)
    # print("Meae :%.4f" % Meae)
    # np.savetxt('' + str(kernel) + '.csv', Y_pred, delimiter=',')
