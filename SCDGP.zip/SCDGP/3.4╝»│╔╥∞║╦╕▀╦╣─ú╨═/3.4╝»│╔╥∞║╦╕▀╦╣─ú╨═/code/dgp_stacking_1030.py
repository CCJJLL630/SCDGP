import math
import time

import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn import svm, manifold
from sklearn.decomposition import KernelPCA
from sklearn.linear_model import RidgeCV, LassoCV
from xgboost import XGBRegressor
from sklearn.ensemble \
    import RandomForestRegressor, AdaBoostRegressor, GradientBoostingRegressor, StackingRegressor,HistGradientBoostingRegressor

from sklearn.tree import ExtraTreeRegressor, DecisionTreeRegressor
import lightgbm as lgb
np.random.seed(42)
import gpflow
import gpflux

from gpflow.config import default_float
from sklearn.metrics import median_absolute_error, explained_variance_score, mean_absolute_error, mean_squared_error, \
    r2_score
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler
import csv
tf.keras.backend.set_floatx("float64")
with open('D:\CJL\DGP\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\jiediansunhao-cjl.CSV', 'r') as f:
    reader = csv.reader(f)
    data = []
    for i in reader:
        data += [[float(j) for j in i]]
t = np.array(data)
data = np.swapaxes(t, 0, 1)
X = np.swapaxes(data[:8], 0, 1)
y = np.swapaxes(data[8:], 0, 1)

# with open('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data/jieguo700.csv', 'r') as f:
#     reader = csv.reader(f)
#     data = []
#     for i in reader:
#         data += [[float(j) for j in i]]
# t = np.array(data)
# data = np.swapaxes(t, 0, 1)
# X = np.swapaxes(data[:4], 0, 1)
# y = np.swapaxes(data[4:], 0, 1)
from sklearn.preprocessing import scale, MinMaxScaler,RobustScaler,StandardScaler
X = scale(X)
y = scale(y)
# scaler = StandardScaler()
# X = scaler.fit_transform(X)
# y = scaler.fit_transform(y)
# mm = MinMaxScaler()
# X = mm.fit_transform(X)
# y = mm.fit_transform(y)

kPCA = KernelPCA(kernel="rbf",n_components=4)
se = manifold.LocallyLinearEmbedding(n_components=1,n_neighbors=50)
X = kPCA.fit_transform(X)
kPCA1 = KernelPCA(kernel="rbf",n_components=1)
y = kPCA1.fit_transform(y)
start = time.time()

model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)
ridge = RidgeCV()
lasso = LassoCV()
import Matern_52_kernel
import Matern_32_kernel
import Exp_kernel
import RQ_kernel
import SE_kernel
model_matern52 = Matern_52_kernel.model_Matern52_kernel
model_RQ = RQ_kernel.model_RQ_kernel
model_Exp = Exp_kernel.model_Exp_kernel
model_matern32 = Matern_32_kernel.model_Matern32_kernel
model_SE = SE_kernel.model_SE_kernel
kfold = KFold(n_splits=5)

R2_l = []
R22_l = []
Mse_l = []
Mae_l = []
Rmse_l = []
Variance_l = []
Y_Pred = []
Y_Test = []

for train, test in kfold.split(X):
    X_train = np.array(X)[train]
    y_train = np.array(y)[train]
    # print(X_train,y_train)
    X_test = np.array(X)[test]
    y_test = np.array(y)[test]
    estimators = [('rf', RandomForestRegressor()),
              # ('gb',GradientBoostingRegressor()),
              ('gbm', lgb.sklearn.LGBMRegressor()),
              # ('ad',AdaBoostRegressor()),
              #('hgd',HistGradientBoostingRegressor()),
              ('xg',XGBRegressor()),
              ('ex', ExtraTreeRegressor()),
             ('dt', DecisionTreeRegressor())
              ]
    final_layer = StackingRegressor(
        estimators=[
            # ('dt',DecisionTreeRegressor()),
            # ('rf',RandomForestRegressor()),
            ('ad', AdaBoostRegressor()),
            # ('ex',ExtraTreeRegressor()),('hr',HistGradientBoostingRegressor()),
            # ('RQ',model_RQ,('Exp'),model_Exp),('SE',model_SE),
            ('matern52', model_matern52),
            ('matern32', model_matern32),
            ('Exp',model_Exp),
            ('RQ',model_RQ)
        ],
        # estimators = [('dt',DecisionTreeRegressor())],
        # estimators = [('RQ',model_RQ)],
        final_estimator=model_SVR
    )
    model = StackingRegressor(estimators=estimators, final_estimator=final_layer)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)


    # calculate metrics
    R2 = r2_score(y_test, y_pred, multioutput='raw_values')  # 拟合优度
    R22 = 1 - math.sqrt(1 - R2)
    Mse = mean_squared_error(y_test, y_pred)  # 均方差
    Mae = mean_absolute_error(y_test, y_pred,
                              sample_weight=None,
                              multioutput='uniform_average')  # 平均绝对误差
    Variance = explained_variance_score(y_test, y_pred,
                                        sample_weight=None,
                                        multioutput='uniform_average')  # 可释方差得分
    Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差
    print("R2 :%.4f" % R2)
    print("R22 :%.4f" % R22)
    print("Mse :%.4f" % Mse)
    print("Rmse :%.4f" % math.sqrt(Mse))
    print("Mae :%.4f" % Mae)
    print("Variance :%.4f" % Variance)
    print("Meae :%.4f" % Meae)
    R2_l.append(R2)
    R22_l.append(R22)
    Mse_l.append(Mse)
    Rmse_l.append(math.sqrt(Mse))
    Variance_l.append(Variance)
    Mae_l.append(Mae)

print('R2:',np.mean(R2_l))
print('R22:',np.mean(R22_l))
print('Mse:',np.mean(Mse_l))
print('Rmse:',np.mean(Rmse_l))
print('Variance:',np.mean(Variance_l))
print('Mae:',np.mean(Mae_l))
end = time.time()
time = end - start
print('time is :',time)