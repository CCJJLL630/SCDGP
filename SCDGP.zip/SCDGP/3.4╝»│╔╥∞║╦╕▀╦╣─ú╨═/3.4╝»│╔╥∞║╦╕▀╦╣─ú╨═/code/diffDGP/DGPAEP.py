'''

'''
# import deepgp
import sys

sys.path.append(r'/home/songyifan/python/python/DGP/deepGP_approxEP-master')
from DGP.EP import AEPDGP_net
import GPy
import time
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.distance import cdist, pdist
from pandas import read_csv
from sklearn.cluster import KMeans
from sklearn import datasets
from sklearn.cluster import DBSCAN
import pandas as pd
from skfuzzy.cluster import cmeans
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.metrics import r2_score, mean_absolute_error, median_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split, KFold, cross_val_score
import math
import random
from scipy import stats
from sklearn.gaussian_process.kernels import RBF, Matern, RationalQuadratic, Exponentiation, ExpSineSquared, \
    ConstantKernel


def split_train(data, test_ratio):
    np.random.seed(436)
    shuffled_indices = np.random.permutation(len(data))
    test_set_size = int(len(data) * test_ratio)
    test_indices = shuffled_indices[:test_set_size]
    train_indices = shuffled_indices[test_set_size:]
    return data[train_indices], data[test_indices]


# dataframe = read_csv("data/kongzai10000.csv", header=None)
# dataframe = read_csv("data/6000.csv", header=None)
# dataframe = read_csv("data/PM2.5.csv", header=None)
dataframe = read_csv("D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\\dianji_cjl.CSV", header=None)
# dataframe = read_csv("data/auto.csv", header=None)
dataset = dataframe.values
row, column = dataset.shape
print(row, column)
# column = column - 1
X = dataset[:,0:column-1]
# for battery_prediction
# x = df2[:,1:column-1]
Y = dataset[:,column-1:column]

from sklearn.preprocessing import scale, MinMaxScaler
# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)

X_train,X_test,y_train,y_test = train_test_split(X, Y, test_size=0.2,random_state=42)

nolayers = 2
M = 20
# no_epochs = 10
# n_hiddens = [2]
n_hiddens = [100 for _ in range(nolayers - 1)]
no_points_per_mb = 100
n_pseudos = [M for _ in range(nolayers)]

for no_epochs in range(60, 61, 20):

    net = AEPDGP_net.AEPDGP_net(X_train, y_train, n_hiddens, n_pseudos)
        # We construct the network
        # train
    start = time.time()
    test_nll, test_rms, energy = net.fit(no_epochs=no_epochs,
                                             no_points_per_mb=no_points_per_mb,
                                             lrate=0.01, compute_logZ=True)
    #     y_predicted,v = net.predict(x_test)
    end = time.time()
    total_time = end - start
    print('total_time:', total_time)
    #     # yy.append(y_predicted)
    #     # print('yy:',yy)

    y_predicted, v = net.predict(X_test)
    print('y_predicted.shape', y_predicted.shape)
    # print('y_predicted:',y_predicted)


    R2 = r2_score(y_test, y_predicted)
    R22 = 1 - math.sqrt(1 - R2)
    mse = mean_squared_error(y_test, y_predicted)
    rmse = math.sqrt(mse)
    Mae = mean_absolute_error(y_test, y_predicted,
                              sample_weight=None,
                              multioutput='uniform_average')  # 平均绝对误差

    Meae = median_absolute_error(y_test, y_predicted)  # 中值绝对误差
    time12 = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("当前模型训练结束，时间为： " + time12)
    print("R2 :%.4f" % R2)
    print("R22 :%.4f" % R22)
    print("Mse :%.4f" % mse)
    print("Rmse :%.4f" % rmse)
    print("Mae :%.4f" % Mae)
    print("Meae :%.4f" % Meae)
    # print('total_time:', total_time)






