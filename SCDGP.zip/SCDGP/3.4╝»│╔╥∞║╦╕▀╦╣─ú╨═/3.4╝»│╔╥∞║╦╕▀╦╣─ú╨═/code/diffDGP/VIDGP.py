import abc
import math
import time

import numpy as np
import pandas as pd
import sklearn.feature_selection
import tensorflow as tf
import matplotlib.pyplot as plt
from gpflow.kernels import MultioutputKernel, Combination, SharedIndependent, SquaredExponential, Linear
from scikeras.wrappers import KerasRegressor
from sklearn import svm, manifold
from sklearn.decomposition import KernelPCA
from sklearn.ensemble import RandomForestRegressor, AdaBoostRegressor, GradientBoostingRegressor, StackingRegressor
from sklearn.tree import ExtraTreeRegressor
from tensorflow import keras

np.random.seed(42)
import gpflow
import gpflux

from gpflow.config import default_float
from sklearn.metrics import median_absolute_error, explained_variance_score, mean_absolute_error, mean_squared_error, \
    r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import stackingModel
import Exp_kernel


tf.keras.backend.set_floatx("float64")













# dataframe = pd.read_csv("data/jiedianchangshu.csv", header=None)
# dataframe = pd.read_csv("data/covid-Italy.csv", header=None)
# dataframe = pd.read_excel("data/25_soc2000.xls", header=0)
# dataframe = pd.read_csv("data/jiediansunhao.csv", header=None)
# dataframe = pd.read_csv("data/bancao.csv", header=None)
# dataframe = pd.read_csv("data/multi792.csv", header=None)
# dataframe = pd.read_csv("data/battery4900.csv", header=None)
# dataframe = pd.read_csv("data/battery12000.csv", header=None)
# dataframe = pd.read_csv("data/battery_origin.csv", header=None)
# dataframe = dataframe.sample(frac=0.1, replace=False, random_state=42)
# dataframe = pd.read_csv("data/pushi/CBM.csv", header=None)
# dataframe = pd.read_csv("data/pushi/concrete.csv", header=None)
# dataframe = pd.read_csv("data/pushi/kin8nm.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-red.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-white.csv", header=None)
# dataframe = pd.read_csv("data/pushi/yacht.csv", header=None)
dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\dianji_cjl.CSV',header=None)
dataset = dataframe.values
row, column = dataset.shape
#print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

X = df2[:,0:column-1]
Y = df2[:,column-1:column]
# for battery_prediction
# x = df2[:,1:column-1]

# X = df2[:,0:6]
# X = np.delete(X, 3, 1)
# X = np.delete(X, 4, 1)
# print('x_shape',X.shape)
# Y = df2[:,6:7]
# Y = df2[:,7:8]
# Y = df2[:8:9]
# Y = df2[:,9:10]
# Y = df2[:,10:11]
from sklearn.preprocessing import scale, MinMaxScaler
# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)

# from sklearn.decomposition import PCA
# pca = PCA(n_components=1)
# Y = pca.fit_transform(Y)
# # PCA(copy=True, n_components=2, whiten=False)
# print('pca_value:',pca.explained_variance_ratio_)

# kPCA = KernelPCA(kernel="poly",n_components=1)
# se = manifold.LocallyLinearEmbedding(n_components=1,n_neighbors=50)
# X = kPCA.fit_transform(X)
# print('-----------------------------------------')
# print('X.shape = ',X.shape)
# print('-----------------------------------------')
# kPCA1 = KernelPCA(kernel="rbf",n_components=1)
# Y = kPCA1.fit_transform(Y)
# print(X.shape,Y.shape)
num_data, input_dim = X.shape

X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)
print('X_train.shape = ',X_train.shape)
print('Y_train.shape = ',Y_train.shape)
# X_train = X_train.reshape(X_train.shape[0],1,X_train.shape[1])
# X_test = X_test.reshape(X_test.shape[0],1,X_test.shape[1])
# print(X_train.shape)








# dataframe = pd.read_csv("D:\CjlNoFile\组会文件\深度高斯过程\\3.4集成异核高斯模型\\3.4集成异核高斯模型\data\multi792.csv", header=None)
#
# #dataframe = pd.read_csv("data/jiedian-cjl.CSV", header=None)
#
# # dataframe = pd.read_csv("data/bancao.csv", header=None)
# dataset = dataframe.values
# print(dataset.dtype)
# row, column = dataset.shape
# print(row, column)
# X = dataset[:,0:4]
# # X = np.delete(X, 3, 1)
# # X = np.delete(X, 4, 1)
# y = dataset[:,4:column]
# from sklearn.preprocessing import MinMaxScaler,scale
# # mm = MinMaxScaler()
# # X = mm.fit_transform(X)
# # y = mm.fit_transform(y)
# X = scale(X)
# y = scale(y)


#
# print('X_train.shape = ',X_train.shape)
# print('Y_train.shape = ',Y_train.shape)
#
#











num_data = len(X)
num_inducing = 20
output_dim = Y_train.shape[1]
print('output_dim = ',output_dim)
# output_dim = 100
SE_kernel = gpflow.kernels.SquaredExponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_SE = gpflux.layers.GPLayer(
    SE_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
RQ_kernel = gpflow.kernels.RationalQuadratic()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_RQ = gpflux.layers.GPLayer(
    RQ_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
Matern52_kernel = gpflow.kernels.Matern52()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_Matern52 = gpflux.layers.GPLayer(
    Matern52_kernel, inducing_variable, num_data=num_data, num_latent_gps=output_dim
)
Matern32_kernel = gpflow.kernels.Matern32()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)
gp_layer_Matern32 = gpflux.layers.GPLayer(
    Matern32_kernel, inducing_variable, num_data=num_data, num_latent_gps= output_dim
)
Exp_kernel = gpflow.kernels.Exponential()
inducing_variable = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)

# class CustomMultiOutput(MultioutputKernel, Combination):
#     def __init__(self, kernels, name=None):
#         kernels = [SharedIndependent(k, output_dim=output_dim) for k in kernels]
#         super().__init__(kernels=kernels, name=name)
#
#     @property
#     def num_latent_gps(self):
#         return len(self.kernels)
#
#     @property
#     def latent_kernels(self):
#         """The underlying kernels in the multioutput kernel"""
#         return tuple(self.kernels)



multi_kernel = gpflow.kernels.SharedIndependent(gpflow.kernels.RBF()+gpflow.kernels.Matern52(),output_dim)
#multi_kernel = gpflow.kernels.Matern32()

inducing_variable_mluti = gpflow.inducing_variables.InducingPoints(
    np.linspace(X.min(), X.max(), num_inducing).reshape(-1, 1)
)


likelihood = gpflow.likelihoods.Gaussian()
M = 50
# So that Keras can track the likelihood variance, we need to provide the likelihood as part of a "dummy" layer:
likelihood_container = gpflux.layers.TrackableLayer()
likelihood_container.likelihood = likelihood


model = tf.keras.Sequential(
    [
#         tf.keras.layers.Dense(M, activation="relu"),
#         tf.keras.layers.Dense(M, activation="relu"),
# tf.keras.layers.Dense(M, activation="relu"),
# tf.keras.layers.Dense(M, activation="relu"),

        tf.keras.layers.Dense(1, activation="linear"),
        gp_layer_SE,
gp_layer_SE,
gp_layer_SE,

        likelihood_container,  # no-op, for discovering trainable likelihood parameters
    ]
)

# model = tf.keras.Sequential(
#     [   #tf.keras.layers.Input(shape = ),
#
#
#         #tf.keras.layers.LSTM(64),
#         #tf.keras.layers.Flatten(),
#
#
#
#         #tf.keras.layers.Dense(4, activation="relu"),
# tf.keras.layers.Dense(1, activation="linear"),
# #tf.keras.layers.Flatten(),
#         #gp_layer_multioutput,
#     #gp_layer_Matern32,
#
#         gp_layer_multioutput,
#
# #tf.keras.layers.Dense(1, activation="linear"),
#         #gp_layer_Matern32,
#         #tf.keras.layers.Dense(20, activation="linear"),
#         likelihood_container,  # no-op, for discovering trainable likelihood parameters
#     ]
# )

loss = gpflux.losses.LikelihoodLoss(likelihood)
import Matern_52_kernel
import Matern_32_kernel
import Exp_kernel
import RQ_kernel
import MultiOutput_kernel
model_SVR = svm.SVR(kernel='linear', gamma=0.1, C=100)
model_rbfsvr = svm.SVR(kernel='rbf', gamma=0.1, C=100)
model_matern52 = Matern_52_kernel.model_Matern52_kernel
model_RQ = RQ_kernel.model_RQ_kernel
model_Exp = Exp_kernel.model_Exp_kernel
model_matern32 = Matern_32_kernel.model_Matern32_kernel
model_multi = MultiOutput_kernel.model_multi_kernel

# estimators4 = [
#     # ('RQ', model_RQ),
#     # ('Exp', model_Exp),
#     ('matern52', model_matern52),
#     #('matern32', model_matern32)
#     ]
#model = StackingRegressor(estimators=estimators3)
#model = model_multi
model.compile(loss=loss, optimizer="adam")
hist = model.fit(X_train, Y_train, epochs=1000, verbose=0)

#model.fit(X_train,Y_train)
#y,y_pred = modeltest.predict_y(X_train)
start_time = time.time()
y_pred = model.predict(X_test)
end_time = time.time() - start_time
print('y_pred.shape = ',y_pred.shape)
print('y_pred = ',y_pred)
print('Time to compute 4 SE DGP {:.2f}s'.format(end_time))
y_test = Y_test

#calculate metrics
R2 = r2_score(y_test, y_pred, multioutput='raw_values')  # 拟合优度
R22 = 1 - math.sqrt(1 - R2)
Mse = mean_squared_error(y_test, y_pred)  # 均方差
Mae = mean_absolute_error(y_test, y_pred,
                          sample_weight=None,
                          multioutput='uniform_average')  # 平均绝对误差
Variance = explained_variance_score(y_test, y_pred,
                                    sample_weight=None,
                                    multioutput='uniform_average')  # 可释方差得分
Meae = median_absolute_error(y_test, y_pred)  # 中值绝对误差
print("R2 :%.4f" % R2)
print("R22 :%.4f" % R22)
print("Mse :%.4f" % Mse)
print("Rmse :%.4f" % math.sqrt(Mse))
print("Mae :%.4f" % Mae)
print("Variance :%.4f" % Variance)
print("Meae :%.4f" % Meae)
#print("total_time :%.4f" % total_time)





# plt.plot(hist.history["loss"])


def plot(model, X, Y, ax=None):
    if ax is None:
        fig, ax = plt.subplots()

    x_margin = 1.0
    N_test = 6
    X_test = np.linspace(X.min() - x_margin, X.max() + x_margin, N_test).reshape(-1, 1)

    print(X_test.shape)
    f_distribution = model(X_test)

    mean = f_distribution.mean().numpy().squeeze()
    var = f_distribution.variance().numpy().squeeze()
    X_test = X_test.squeeze()
    lower = mean - 2 * np.sqrt(var)
    upper = mean + 2 * np.sqrt(var)

    ax.set_ylim(Y.min() - 0.5, Y.max() + 0.5)
    ax.plot(X, Y, "kx", alpha=0.5)
    ax.plot(X_test, mean, "C1")

    ax.fill_between(X_test, lower, upper, color="C1", alpha=0.3)


# plot(model, X, Y)