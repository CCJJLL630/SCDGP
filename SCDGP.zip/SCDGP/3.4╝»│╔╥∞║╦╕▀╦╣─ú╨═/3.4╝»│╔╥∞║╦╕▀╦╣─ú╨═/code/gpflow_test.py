import gpflow
import matplotlib.pyplot as plt
import numpy as np

import gpflow as gpf
#from gpflow.ci_utils import reduce_in_tests
from gpflow.utilities import print_summary

gpf.config.set_default_float(np.float64)
gpf.config.set_default_summary_fmt("notebook")
np.random.seed(0)






import abc
import math

import numpy as np
import pandas as pd
import sklearn.feature_selection
import tensorflow as tf
import matplotlib.pyplot as plt
from gpflow.kernels import MultioutputKernel, Combination, SharedIndependent, SquaredExponential, Linear
from scikeras.wrappers import KerasRegressor
from sklearn import svm, manifold
from sklearn.decomposition import KernelPCA
from sklearn.ensemble import RandomForestRegressor, AdaBoostRegressor, GradientBoostingRegressor, StackingRegressor
from sklearn.tree import ExtraTreeRegressor
from tensorflow import keras

np.random.seed(42)
import gpflow
import gpflux

from gpflow.config import default_float
from sklearn.metrics import median_absolute_error, explained_variance_score, mean_absolute_error, mean_squared_error, \
    r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import stackingModel
import Exp_kernel


tf.keras.backend.set_floatx("float64")










#
#
#
# dataframe = pd.read_csv("data/jiedianchangshu.csv", header=None)
# dataframe = pd.read_csv("data/covid-Italy.csv", header=None)
# dataframe = pd.read_excel("data/25_soc2000.xls", header=0)
# dataframe = pd.read_csv("data/jiediansunhao.csv", header=None)
# dataframe = pd.read_csv("data/bancao.csv", header=None)
# dataframe = pd.read_csv("data/multi792.csv", header=None)
# dataframe = pd.read_csv("data/battery4900.csv", header=None)
# dataframe = pd.read_csv("data/battery12000.csv", header=None)
# dataframe = pd.read_csv("data/battery_origin.csv", header=None)
# dataframe = dataframe.sample(frac=0.1, replace=False, random_state=42)
# dataframe = pd.read_csv("data/pushi/CBM.csv", header=None)
# dataframe = pd.read_csv("data/pushi/concrete.csv", header=None)
# dataframe = pd.read_csv("data/pushi/kin8nm.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-red.csv", header=None)
# dataframe = pd.read_csv("data/pushi/winequality-white.csv", header=None)
# dataframe = pd.read_csv("data/pushi/yacht.csv", header=None)
dataframe = pd.read_csv('D:\CjlNoFile\组会文件\深度高斯过程//3.4集成异核高斯模型//3.4集成异核高斯模型\data\multi792.csv',header=None)
dataset = dataframe.values
row, column = dataset.shape
#print(row, column)
dataset = dataset[:,0:column]
# for battery_prediction
# dataset = dataset[:,1:column]
df2 = dataframe.copy()
# print("\n原始数据:\n",df2)

# 标准化
# sc_X = StandardScaler()
# df2 = sc_X.fit_transform(df2)
# df2 = pd.DataFrame(data=df2)
df2 = df2.values
# print(df2.shape)


# df2 = df2.values
# x1 = df2[:,0:4]
# x2 = df2[:,4:column-1]
# y = df2[:,column-1:column]
# print(x1.shape,x2.shape,y.shape)

# X = df2[:,0:column-1]
# Y = df2[:,column-1:column]
X = df2[:,0:column-4]
Y = df2[:,column-4:column]
# for battery_prediction
# x = df2[:,1:column-1]

# X = df2[:,0:6]
# X = np.delete(X, 3, 1)
# X = np.delete(X, 4, 1)
# print('x_shape',X.shape)
# Y = df2[:,6:7]
# Y = df2[:,7:8]
# Y = df2[:8:9]
# Y = df2[:,9:10]
# Y = df2[:,10:11]
from sklearn.preprocessing import scale, MinMaxScaler
# X = scale(X)
# Y = scale(Y)
mm = MinMaxScaler()
X = mm.fit_transform(X)
Y = mm.fit_transform(Y)

# from sklearn.decomposition import PCA
# pca = PCA(n_components=1)
# Y = pca.fit_transform(Y)
# # PCA(copy=True, n_components=2, whiten=False)
# print('pca_value:',pca.explained_variance_ratio_)

kPCA = KernelPCA(kernel="rbf",n_components=1)
se = manifold.LocallyLinearEmbedding(n_components=1,n_neighbors=50)
X = kPCA.fit_transform(X)
print('-----------------------------------------')
print('X.shape = ',X.shape)
print('-----------------------------------------')
kPCA1 = KernelPCA(kernel="rbf",n_components=2)
Y = kPCA1.fit_transform(Y)


# print(X.shape,Y.shape)
num_data, input_dim = X.shape

# X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.5, random_state=42)
# print('X_train.shape = ',X_train.shape)
# print('Y_train.shape = ',Y_train.shape)
# print('X_test.shape = ',X_test.shape)
# print('Y_test.shape = ',Y_test.shape)










#MAXITER = reduce_in_tests(2000)
N = 100  # number of points
D = 1  # number of input dimensions
M = 15  # number of inducing points
L = 2  # number of latent GPs
P = 3  # number of observations = output dimensions

# N = 1580  # number of points
# D = 5  # number of input dimensions
# M = 5  # number of inducing points
# L = 4  # number of latent GPs
# P = 2  # number of observations = output dimensions

def generate_data(N=100):
    X = np.random.rand(N)[:, None] * 10 - 5  # Inputs = N x D
    G = np.hstack((0.5 * np.sin(3 * X) + X, 3.0 * np.cos(X) - X))  # G = N x L
    W = np.array([[0.5, -0.3, 1.5], [-0.4, 0.43, 0.0]])  # L x P
    F = np.matmul(G, W)  # N x P
    Y = F + np.random.randn(*F.shape) * [0.2, 0.2, 0.2]
    print('Y_shape = ',Y.shape)

    return X, Y

#X, Y = data = X_train,Y_train
X, Y = data = generate_data(100)
X_train,X_test,Y_train,Y_test = train_test_split(X, Y, test_size=0.5, random_state=42)
print('X.shape = ',X.shape)
print('Y.shape = ',Y.shape)
Zinit = np.linspace(X.min(), X.max(), M)[:, None]
print('Zinit = ',Zinit)

# def plot_model(m, lower=-8.0, upper=8.0):
#     pX = np.linspace(lower, upper, 100)[:, None]
#     pY, pYv = m.predict_y(pX)
#     if pY.ndim == 3:
#         pY = pY[:, 0, :]
#     plt.plot(X, Y, "x")
#     plt.gca().set_prop_cycle(None)
#     plt.plot(pX, pY)
#     for i in range(pY.shape[1]):
#         top = pY[:, i] + 2.0 * pYv[:, i] ** 0.5
#         bot = pY[:, i] - 2.0 * pYv[:, i] ** 0.5
#         plt.fill_between(pX[:, 0], top, bot, alpha=0.3)
#     plt.xlabel("X")
#     plt.ylabel("f")
#     plt.title(f"ELBO: {m.elbo(data):.3}")
#     plt.plot(Z, Z * 0.0, "o")

# create multi-output kernel
kernel = gpf.kernels.SharedIndependent(
    gpf.kernels.SquaredExponential() + gpf.kernels.Linear(),output_dim=P
)
# initialization of inducing input locations (M random points from the training inputs)
Z = Zinit.copy()
# create multi-output inducing variables from Z
iv = gpf.inducing_variables.SharedIndependentInducingVariables(
    gpf.inducing_variables.InducingPoints(Z)
)
# create SVGP model as usual and optimize
m = gpf.models.SVGP(
    kernel, gpf.likelihoods.Gaussian(), inducing_variable=iv, num_latent_gps=P
)

y,Y_pred  = m.predict_y(X)
print(Y_pred.shape)
# def optimize_model_with_scipy(model):
#     optimizer = gpf.optimizers.Scipy()
#     optimizer.minimize(
#         model.training_loss_closure(data),
#         variables=model.trainable_variables,
#         method="l-bfgs-b",
#         options={"disp": 50, "maxiter": MAXITER},
#     )


#optimize_model_with_scipy(m)
#calculate metrics
R2 = r2_score(Y_test, Y_pred, multioutput='raw_values')  # 拟合优度
R22 = 1 - np.sqrt(1 - R2)
Mse = mean_squared_error(Y_test, Y_pred)  # 均方差
Mae = mean_absolute_error(Y_test, Y_pred,
                          sample_weight=None,
                          multioutput='uniform_average')  # 平均绝对误差
Variance = explained_variance_score(Y_test, Y_pred,
                                    sample_weight=None,
                                    multioutput='uniform_average')  # 可释方差得分
Meae = median_absolute_error(Y_test, Y_pred)  # 中值绝对误差
print("R2_gpflow_test : " , R2)
print("R22 : " , R22)
print("Mse :",  Mse)
print("Rmse :",  np.sqrt(Mse))
print("Mae :",  Mae)
print("Variance :",  Variance)
print("Meae :",  Meae)